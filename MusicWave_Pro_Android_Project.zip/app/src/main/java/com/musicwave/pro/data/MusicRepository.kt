package com.musicwave.pro.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MusicRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("musicwave_prefs", Context.MODE_PRIVATE)

    suspend fun scanDeviceSongs(): List<Song> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            val artworkBaseUri = Uri.parse("content://media/external/audio/albumart")

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "مقطع صوتي غير معروف"
                val rawArtist = cursor.getString(artistCol)
                val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "فنان غير معروف" else rawArtist
                val album = cursor.getString(albumCol) ?: "ألبوم غير معروف"
                val albumId = cursor.getLong(albumIdCol)
                val duration = cursor.getLong(durationCol)
                val path = cursor.getString(dataCol) ?: ""
                val dateAdded = cursor.getLong(dateCol)

                val folderName = try {
                    File(path).parentFile?.name ?: "الموسيقى"
                } catch (e: Exception) {
                    "الموسيقى"
                }

                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    id
                )
                val albumArtUri = ContentUris.withAppendedId(artworkBaseUri, albumId)

                songs.add(
                    Song(
                        id = id,
                        title = title,
                        artist = artist,
                        album = album,
                        duration = duration,
                        contentUri = contentUri,
                        albumArtUri = albumArtUri,
                        folderName = folderName,
                        dateAdded = dateAdded
                    )
                )
            }
        }
        songs
    }

    fun getFavoriteIds(): Set<Long> {
        val raw = prefs.getStringSet("favorite_song_ids", emptySet()) ?: emptySet()
        return raw.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun saveFavoriteIds(ids: Set<Long>) {
        prefs.edit().putStringSet("favorite_song_ids", ids.map { it.toString() }.toSet()).apply()
    }

    fun getPlaylists(): List<Playlist> {
        val jsonStr = prefs.getString("playlists_json", null) ?: return defaultPlaylists()
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<Playlist>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val songsArr = obj.getJSONArray("songIds")
                val songIds = mutableListOf<Long>()
                for (j in 0 until songsArr.length()) {
                    songIds.add(songsArr.getLong(j))
                }
                list.add(
                    Playlist(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        songIds = songIds,
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            defaultPlaylists()
        }
    }

    fun savePlaylists(playlists: List<Playlist>) {
        val array = JSONArray()
        playlists.forEach { playlist ->
            val obj = JSONObject()
            obj.put("id", playlist.id)
            obj.put("name", playlist.name)
            obj.put("createdAt", playlist.createdAt)
            val songsArr = JSONArray()
            playlist.songIds.forEach { songsArr.put(it) }
            obj.put("songIds", songsArr)
            array.put(obj)
        }
        prefs.edit().putString("playlists_json", array.toString()).apply()
    }

    private fun defaultPlaylists(): List<Playlist> = listOf(
        Playlist(id = "pl_shaabi", name = "مهرجانات وشعبي", songIds = emptyList()),
        Playlist(id = "pl_chill", name = "روقان وموال", songIds = emptyList()),
        Playlist(id = "pl_workout", name = "حماس وجيم", songIds = emptyList())
    )
}
