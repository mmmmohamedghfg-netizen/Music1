package com.musicwave.pro.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.musicwave.pro.MainActivity
import com.musicwave.pro.R

class MusicWaveWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_WIDGET_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, MusicWaveWidgetProvider::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }
    }

    companion object {
        const val ACTION_WIDGET_UPDATE = "com.musicwave.pro.ACTION_WIDGET_UPDATE"

        fun notifyWidgetChanged(context: Context, title: String, artist: String, isPlaying: Boolean) {
            val prefs = context.getSharedPreferences("musicwave_widget_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("last_title", title)
                .putString("last_artist", if (isPlaying) "$artist • يعمل الآن" else "$artist • متوقف مؤقتاً")
                .apply()

            val intent = Intent(context, MusicWaveWidgetProvider::class.java).apply {
                action = ACTION_WIDGET_UPDATE
            }
            context.sendBroadcast(intent)
        }

        private fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val prefs = context.getSharedPreferences("musicwave_widget_prefs", Context.MODE_PRIVATE)
            val title = prefs.getString("last_title", "MusicWave Pro") ?: "MusicWave Pro"
            val artist = prefs.getString("last_artist", "اضغط لفتح المشغل والاستماع") ?: "اضغط لفتح المشغل والاستماع"

            val views = RemoteViews(context.packageName, R.layout.widget_music_wave)
            views.setTextViewText(R.id.widget_song_title, title)
            views.setTextViewText(R.id.widget_song_artist, artist)

            val launchIntent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                launchIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
