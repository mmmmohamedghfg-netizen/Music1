package com.musicwave.pro.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.musicwave.pro.MainActivity
import com.musicwave.pro.widget.MusicWaveWidgetProvider

class MusicPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        AudioSessionBridge.updateAudioSessionId(player.audioSessionId)

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioSessionBridge.updateAudioSessionId(audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val title = mediaItem?.mediaMetadata?.title?.toString() ?: "MusicWave Pro"
                val artist = mediaItem?.mediaMetadata?.artist?.toString() ?: "فنان غير معروف"
                MusicWaveWidgetProvider.notifyWidgetChanged(
                    this@MusicPlaybackService,
                    title,
                    artist,
                    player.isPlaying
                )
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val mediaItem = player.currentMediaItem
                val title = mediaItem?.mediaMetadata?.title?.toString() ?: "MusicWave Pro"
                val artist = mediaItem?.mediaMetadata?.artist?.toString() ?: "فنان غير معروف"
                MusicWaveWidgetProvider.notifyWidgetChanged(
                    this@MusicPlaybackService,
                    title,
                    artist,
                    isPlaying
                )
            }
        })

        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(pendingIntent)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
