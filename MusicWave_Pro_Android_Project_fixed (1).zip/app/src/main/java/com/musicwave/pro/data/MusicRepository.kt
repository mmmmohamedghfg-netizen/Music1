package com.musicwave.pro.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.musicwave.pro.model.PersistedSettings
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MusicRepository(private val context: Context) {

    private val dbHelper = MusicDatabaseHelper(context)
    private val backupPrefs = context.getSharedPreferences("musicwave_permanent_settings", Context.MODE_PRIVATE)

    suspend fun scanDeviceSongs(): List<Song> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            val artworkBaseUri = Uri.parse("content://media/external/audio/albumart")

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "مقطع صوتي غير معروف"
                val rawArtist = cursor.getString(artistCol)
                val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "فنان غير معروف" else rawArtist
                val album = cursor.getString(albumCol) ?: "ألبوم غير معروف"
                val albumId = cursor.getLong(albumIdCol)
                val duration = cursor.getLong(durationCol)
                val path = cursor.getString(dataCol) ?: ""
                val dateAdded = cursor.getLong(dateCol)

                val folderName = try {
                    File(path).parentFile?.name ?: "الموسيقى"
                } catch (e: Exception) {
                    "الموسيقى"
                }

                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    id
                )
                val albumArtUri = ContentUris.withAppendedId(artworkBaseUri, albumId)

                songs.add(
                    Song(
                        id = id,
                        title = title,
                        artist = artist,
                        album = album,
                        duration = duration,
                        contentUri = contentUri,
                        albumArtUri = albumArtUri,
                        folderName = folderName,
                        filePath = path,
                        dateAdded = dateAdded
                    )
                )
            }
        }
        songs
    }

    fun getFavoriteIds(): Set<Long> = dbHelper.getFavoriteIds()

    fun setFavorite(songId: Long, isFav: Boolean) = dbHelper.setFavorite(songId, isFav)

    fun getPlaylists(): List<Playlist> = dbHelper.getPlaylists()

    fun createPlaylist(playlist: Playlist) = dbHelper.createPlaylist(playlist)

    fun deletePlaylist(playlistId: String) = dbHelper.deletePlaylist(playlistId)

    fun addSongToPlaylist(playlistId: String, songId: Long) = dbHelper.addSongToPlaylist(playlistId, songId)

    fun removeSongFromPlaylist(playlistId: String, songId: Long) = dbHelper.removeSongFromPlaylist(playlistId, songId)

    fun updatePlaylistSongOrder(playlistId: String, orderedSongIds: List<Long>) {
        dbHelper.updatePlaylistSongOrder(playlistId, orderedSongIds)
    }

    fun saveSetting(key: String, value: String) {
        dbHelper.saveSetting(key, value)
        backupPrefs.edit().putString(key, value).commit()
    }

    fun loadPersistedSettings(): PersistedSettings {
        val dbSettings = dbHelper.loadPersistedSettings()
        return dbSettings.copy(
            themeId = backupPrefs.getString("theme_id", dbSettings.themeId) ?: dbSettings.themeId,
            visualizerId = backupPrefs.getString("visualizer_id", dbSettings.visualizerId) ?: dbSettings.visualizerId,
            sortOptionName = backupPrefs.getString("sort_option", dbSettings.sortOptionName) ?: dbSettings.sortOptionName
        )
    }

    fun getLyricsForSong(song: Song): String {
        val custom = dbHelper.getCustomLyrics(song.id)
        if (!custom.isNullOrBlank()) return custom

        if (song.filePath.isNotBlank()) {
            try {
                val audioFile = File(song.filePath)
                val baseName = audioFile.nameWithoutExtension
                val parent = audioFile.parentFile
                if (parent != null) {
                    val lrcFile = File(parent, "$baseName.lrc")
                    if (lrcFile.exists() && lrcFile.canRead()) {
                        return cleanLrcTimestamps(lrcFile.readText())
                    }
                    val txtFile = File(parent, "$baseName.txt")
                    if (txtFile.exists() && txtFile.canRead()) {
                        return txtFile.readText()
                    }
                }
            } catch (_: Exception) {
            }
        }

        return ""
    }

    fun saveLyricsForSong(songId: Long, lyrics: String) {
        dbHelper.saveCustomLyrics(songId, lyrics)
    }

    private fun cleanLrcTimestamps(rawLrc: String): String {
        return rawLrc.lines()
            .map { line -> line.replace(Regex("""\[\d{2}:\d{2}(\.\d{1,3})?]"""), "").trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
    }
}
