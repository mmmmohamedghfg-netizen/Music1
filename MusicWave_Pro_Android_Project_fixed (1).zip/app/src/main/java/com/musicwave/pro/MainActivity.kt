package com.musicwave.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.musicwave.pro.ui.MusicWaveApp
import com.musicwave.pro.viewmodel.MusicViewModel

class MainActivity : ComponentActivity() {

    private val musicViewModel: MusicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var hasAudioPermission by remember { mutableStateOf(checkAudioPermission()) }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    val granted = permissions[Manifest.permission.READ_MEDIA_AUDIO] == true ||
                        permissions[Manifest.permission.READ_EXTERNAL_STORAGE] == true
                    hasAudioPermission = granted
                    if (granted) {
                        musicViewModel.loadSongs()
                    }
                    if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
                        musicViewModel.attachRealVisualizer()
                    }
                }

                LaunchedEffect(hasAudioPermission) {
                    if (hasAudioPermission) {
                        musicViewModel.loadSongs()
                    }
                }

                MusicWaveApp(
                    viewModel = musicViewModel,
                    hasPermission = hasAudioPermission,
                    onRequestPermission = {
                        val perms = mutableListOf<String>()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
                            perms.add(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                        perms.add(Manifest.permission.RECORD_AUDIO)
                        permissionLauncher.launch(perms.toTypedArray())
                    },
                    onOpenSystemEqualizer = {
                        try {
                            val eqIntent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
                                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                            }
                            startActivity(eqIntent)
                        } catch (e: Exception) {
                            Toast.makeText(
                                this,
                                "معادل الصوت المدمج 5-Band EQ متاح ويعمل داخل التطبيق",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }
    }

    private fun checkAudioPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
    }
}
