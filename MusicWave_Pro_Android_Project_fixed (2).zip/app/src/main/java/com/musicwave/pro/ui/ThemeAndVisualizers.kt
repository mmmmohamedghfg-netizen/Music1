package com.musicwave.pro.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.musicwave.pro.model.AppThemeType
import com.musicwave.pro.model.VisualizerMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class ThemeIconPack(
    val headerBadge: ImageVector,
    val tabSongs: ImageVector,
    val tabPlaylists: ImageVector,
    val tabFavorites: ImageVector,
    val tabFolders: ImageVector,
    val favActive: ImageVector,
    val favInactive: ImageVector,
    val playFilled: ImageVector,
    val pauseFilled: ImageVector,
    val equalizer: ImageVector,
    val artworkCenter: ImageVector,
    val ambient: ImageVector = Icons.Default.MusicNote
)

data class ThemeStyleSpec(
    val type: AppThemeType,
    val bgDark: Color,
    val bgTopGradient: Color,
    val cardColor: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val cardShape: Shape,
    val buttonShape: Shape,
    val miniPlayerShape: Shape,
    val artworkShape: Shape,
    val cardBorderWidth: Dp,
    val isCircularArtwork: Boolean,
    val icons: ThemeIconPack
)

fun resolveThemeStyle(theme: AppThemeType): ThemeStyleSpec {
    return when (theme) {
        AppThemeType.NEON_CYBER -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF0B0C14),
            bgTopGradient = Color(0xFF191B34),
            cardColor = Color(0xFF17192B),
            accentPrimary = Color(0xFF00E5FF),
            accentSecondary = Color(0xFFFF2A85),
            textPrimary = Color(0xFFF5F7FF),
            textSecondary = Color(0xFF9EA4C8),
            cardShape = RoundedCornerShape(16.dp),
            buttonShape = RoundedCornerShape(12.dp),
            miniPlayerShape = RoundedCornerShape(18.dp),
            artworkShape = RoundedCornerShape(32.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.GraphicEq,
                tabSongs = Icons.Default.LibraryMusic,
                tabPlaylists = Icons.Default.QueueMusic,
                tabFavorites = Icons.Default.Favorite,
                tabFolders = Icons.Default.Folder,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.MusicNote,
                ambient = Icons.Default.GraphicEq
            )
        )

        AppThemeType.LA_CASA_RED -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF09090B),
            bgTopGradient = Color(0xFF2B070B),
            cardColor = Color(0xFF181214),
            accentPrimary = Color(0xFFE50914),
            accentSecondary = Color(0xFFFFB703),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFB8A9AC),
            cardShape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp, topEnd = 4.dp, bottomStart = 4.dp),
            buttonShape = CutCornerShape(10.dp),
            miniPlayerShape = CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp),
            artworkShape = CutCornerShape(28.dp),
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.TheaterComedy,
                tabSongs = Icons.Default.Audiotrack,
                tabPlaylists = Icons.Default.FeaturedPlayList,
                tabFavorites = Icons.Default.LocalFireDepartment,
                tabFolders = Icons.Default.Inventory2,
                favActive = Icons.Default.LocalFireDepartment,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayArrow,
                pauseFilled = Icons.Default.Pause,
                equalizer = Icons.Default.Tune,
                artworkCenter = Icons.Default.Shield,
                ambient = Icons.Default.LocalFireDepartment
            )
        )

        AppThemeType.ROYAL_GOLD -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF0E0C08),
            bgTopGradient = Color(0xFF282011),
            cardColor = Color(0xFF1C170E),
            accentPrimary = Color(0xFFFFD700),
            accentSecondary = Color(0xFFFF8C00),
            textPrimary = Color(0xFFFFFBF0),
            textSecondary = Color(0xFFC8B88A),
            cardShape = RoundedCornerShape(topStart = 24.dp, bottomEnd = 24.dp, topEnd = 8.dp, bottomStart = 8.dp),
            buttonShape = RoundedCornerShape(50),
            miniPlayerShape = RoundedCornerShape(26.dp),
            artworkShape = CircleShape,
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.WorkspacePremium,
                tabSongs = Icons.Default.Stars,
                tabPlaylists = Icons.Default.AutoStories,
                tabFavorites = Icons.Default.Diamond,
                tabFolders = Icons.Default.FolderSpecial,
                favActive = Icons.Default.Grade,
                favInactive = Icons.Default.StarBorder,
                playFilled = Icons.Default.PlayCircle,
                pauseFilled = Icons.Default.PauseCircle,
                equalizer = Icons.Default.AutoGraph,
                artworkCenter = Icons.Default.WorkspacePremium,
                ambient = Icons.Default.Stars
            )
        )

        AppThemeType.SHAABI_FESTIVAL -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF11071F),
            bgTopGradient = Color(0xFF330C4D),
            cardColor = Color(0xFF211038),
            accentPrimary = Color(0xFFFF6D00),
            accentSecondary = Color(0xFFD500F9),
            textPrimary = Color(0xFFFFF8F0),
            textSecondary = Color(0xFFC7A4E0),
            cardShape = CutCornerShape(12.dp),
            buttonShape = RoundedCornerShape(16.dp),
            miniPlayerShape = RoundedCornerShape(22.dp),
            artworkShape = CutCornerShape(24.dp),
            cardBorderWidth = 2.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Speaker,
                tabSongs = Icons.Default.SpeakerGroup,
                tabPlaylists = Icons.Default.QueuePlayNext,
                tabFavorites = Icons.Default.Bolt,
                tabFolders = Icons.Default.Topic,
                favActive = Icons.Default.Bolt,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.SurroundSound,
                artworkCenter = Icons.Default.Campaign,
                ambient = Icons.Default.Bolt
            )
        )

        AppThemeType.RETRO_VINYL -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF14110E),
            bgTopGradient = Color(0xFF2E2318),
            cardColor = Color(0xFF241D17),
            accentPrimary = Color(0xFFFFB300),
            accentSecondary = Color(0xFFFF5722),
            textPrimary = Color(0xFFFAF0E4),
            textSecondary = Color(0xFFB8A28B),
            cardShape = RoundedCornerShape(28.dp),
            buttonShape = RoundedCornerShape(50),
            miniPlayerShape = RoundedCornerShape(50),
            artworkShape = CircleShape,
            cardBorderWidth = 1.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Album,
                tabSongs = Icons.Default.Radio,
                tabPlaylists = Icons.Default.Subscriptions,
                tabFavorites = Icons.Default.Favorite,
                tabFolders = Icons.Default.Storage,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.SettingsInputComponent,
                artworkCenter = Icons.Default.Album,
                ambient = Icons.Default.Album
            )
        )

        AppThemeType.EMERALD_GLASS -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF061317),
            bgTopGradient = Color(0xFF0B2E36),
            cardColor = Color(0xFF0F242A),
            accentPrimary = Color(0xFF00E676),
            accentSecondary = Color(0xFF00B0FF),
            textPrimary = Color(0xFFEFFFF6),
            textSecondary = Color(0xFF8AB8B0),
            cardShape = RoundedCornerShape(22.dp),
            buttonShape = RoundedCornerShape(18.dp),
            miniPlayerShape = RoundedCornerShape(24.dp),
            artworkShape = RoundedCornerShape(40.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.AutoAwesome,
                tabSongs = Icons.Default.Headphones,
                tabPlaylists = Icons.Default.PlaylistPlay,
                tabFavorites = Icons.Default.Spa,
                tabFolders = Icons.Default.SnippetFolder,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.Headset,
                ambient = Icons.Default.AutoAwesome
            )
        )
        AppThemeType.OCEAN_DEEP -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF04101C),
            bgTopGradient = Color(0xFF0A2A4A),
            cardColor = Color(0xFF0B1F33),
            accentPrimary = Color(0xFF29B6F6),
            accentSecondary = Color(0xFF00E5C3),
            textPrimary = Color(0xFFEAF7FF),
            textSecondary = Color(0xFF7FA6C2),
            cardShape = RoundedCornerShape(20.dp),
            buttonShape = RoundedCornerShape(14.dp),
            miniPlayerShape = RoundedCornerShape(30.dp),
            artworkShape = RoundedCornerShape(48.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Waves,
                tabSongs = Icons.Default.DirectionsBoat,
                tabPlaylists = Icons.Default.Explore,
                tabFavorites = Icons.Default.Anchor,
                tabFolders = Icons.Default.Landscape,
                favActive = Icons.Default.Anchor,
                favInactive = Icons.Default.Waves,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Tune,
                artworkCenter = Icons.Default.Waves,
                ambient = Icons.Default.Waves
            )
        )

        AppThemeType.SUNSET_BLAZE -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF140A0D),
            bgTopGradient = Color(0xFF3D1220),
            cardColor = Color(0xFF231018),
            accentPrimary = Color(0xFFFF7043),
            accentSecondary = Color(0xFFFFCA28),
            textPrimary = Color(0xFFFFF3EC),
            textSecondary = Color(0xFFCFA39A),
            cardShape = RoundedCornerShape(topStart = 28.dp, bottomEnd = 28.dp, topEnd = 10.dp, bottomStart = 10.dp),
            buttonShape = RoundedCornerShape(50),
            miniPlayerShape = RoundedCornerShape(28.dp),
            artworkShape = CircleShape,
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.WbSunny,
                tabSongs = Icons.Default.Terrain,
                tabPlaylists = Icons.Default.Cloud,
                tabFavorites = Icons.Default.Whatshot,
                tabFolders = Icons.Default.Landscape,
                favActive = Icons.Default.Whatshot,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircle,
                pauseFilled = Icons.Default.PauseCircle,
                equalizer = Icons.Default.AutoGraph,
                artworkCenter = Icons.Default.WbSunny,
                ambient = Icons.Default.WbSunny
            )
        )

        AppThemeType.SAKURA_PINK -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF160B13),
            bgTopGradient = Color(0xFF3A1530),
            cardColor = Color(0xFF241320),
            accentPrimary = Color(0xFFFF80AB),
            accentSecondary = Color(0xFFB388FF),
            textPrimary = Color(0xFFFFF0F6),
            textSecondary = Color(0xFFD1A3BA),
            cardShape = RoundedCornerShape(26.dp),
            buttonShape = RoundedCornerShape(20.dp),
            miniPlayerShape = RoundedCornerShape(32.dp),
            artworkShape = RoundedCornerShape(topStart = 60.dp, bottomEnd = 60.dp, topEnd = 16.dp, bottomStart = 16.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.LocalFlorist,
                tabSongs = Icons.Default.FilterVintage,
                tabPlaylists = Icons.Default.Eco,
                tabFavorites = Icons.Default.Favorite,
                tabFolders = Icons.Default.Spa,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.LocalFlorist,
                ambient = Icons.Default.LocalFlorist
            )
        )

        AppThemeType.GALAXY_VIOLET -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF0A0716),
            bgTopGradient = Color(0xFF21104A),
            cardColor = Color(0xFF160E2E),
            accentPrimary = Color(0xFFB388FF),
            accentSecondary = Color(0xFF40C4FF),
            textPrimary = Color(0xFFF3EEFF),
            textSecondary = Color(0xFF9D93C9),
            cardShape = CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp),
            buttonShape = CutCornerShape(12.dp),
            miniPlayerShape = CutCornerShape(topStart = 20.dp, bottomEnd = 20.dp),
            artworkShape = CircleShape,
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Public,
                tabSongs = Icons.Default.Satellite,
                tabPlaylists = Icons.Default.Explore,
                tabFavorites = Icons.Default.Stars,
                tabFolders = Icons.Default.DarkMode,
                favActive = Icons.Default.Stars,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircle,
                pauseFilled = Icons.Default.PauseCircle,
                equalizer = Icons.Default.SurroundSound,
                artworkCenter = Icons.Default.Public,
                ambient = Icons.Default.Flare
            )
        )

        AppThemeType.MATRIX_HACKER -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF020A04),
            bgTopGradient = Color(0xFF062410),
            cardColor = Color(0xFF08160B),
            accentPrimary = Color(0xFF39FF14),
            accentSecondary = Color(0xFF00C853),
            textPrimary = Color(0xFFD9FFE0),
            textSecondary = Color(0xFF6FA87B),
            cardShape = RoundedCornerShape(4.dp),
            buttonShape = RoundedCornerShape(4.dp),
            miniPlayerShape = RoundedCornerShape(6.dp),
            artworkShape = RoundedCornerShape(8.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Code,
                tabSongs = Icons.Default.Memory,
                tabPlaylists = Icons.Default.Dns,
                tabFavorites = Icons.Default.Security,
                tabFolders = Icons.Default.Storage,
                favActive = Icons.Default.Security,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayArrow,
                pauseFilled = Icons.Default.Pause,
                equalizer = Icons.Default.SettingsInputComponent,
                artworkCenter = Icons.Default.Memory,
                ambient = Icons.Default.Code
            )
        )

        AppThemeType.ICE_FROST -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF071018),
            bgTopGradient = Color(0xFF123049),
            cardColor = Color(0xFF0D1C28),
            accentPrimary = Color(0xFF80DEEA),
            accentSecondary = Color(0xFFE1F5FE),
            textPrimary = Color(0xFFF2FBFF),
            textSecondary = Color(0xFF8FB4C4),
            cardShape = RoundedCornerShape(18.dp),
            buttonShape = RoundedCornerShape(14.dp),
            miniPlayerShape = RoundedCornerShape(22.dp),
            artworkShape = RoundedCornerShape(36.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.AcUnit,
                tabSongs = Icons.Default.Grain,
                tabPlaylists = Icons.Default.Cloud,
                tabFavorites = Icons.Default.Diamond,
                tabFolders = Icons.Default.FolderSpecial,
                favActive = Icons.Default.Diamond,
                favInactive = Icons.Default.StarBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.AcUnit,
                ambient = Icons.Default.AcUnit
            )
        )
    }
}

@Composable
fun HyperRealisticVisualizer(
    mode: VisualizerMode,
    isPlaying: Boolean,
    driver: AudioDriver,
    primaryColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
        .fillMaxWidth(0.92f)
        .height(92.dp)
) {
    // Peak hold memory for gravity peak caps
    val peakHold = remember { FloatArray(BAR_COUNT) { 0.15f } }

    Canvas(modifier = modifier) {
        val t = driver.time
        val phase = t * 8.7266f
        val slowPhase = t * 65.4545f
        val barCount = BAR_COUNT
        val currentLevels = driver.levels

        for (i in 0 until barCount) {
            val level = currentLevels[i]
            if (level >= peakHold[i]) {
                peakHold[i] = level
            } else {
                peakHold[i] = (peakHold[i] - 0.018f).coerceAtLeast(level)
            }
        }

        val bassAvg = driver.bass

        when (mode) {
            VisualizerMode.SPECTRUM_PEAKS -> {
                val space = 4.dp.toPx()
                val barW = (size.width - (barCount - 1) * space) / barCount
                for (i in 0 until barCount) {
                    val h = size.height * 0.85f * currentLevels[i]
                    val x = i * (barW + space)
                    val topY = size.height - h
                    val brush = Brush.verticalGradient(
                        colors = listOf(secondaryColor, primaryColor, primaryColor.copy(alpha = 0.35f)),
                        startY = topY,
                        endY = size.height
                    )
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(x, topY),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                    // Floating gravity peak cap
                    val peakY = (size.height - size.height * 0.85f * peakHold[i] - 4.dp.toPx()).coerceAtLeast(0f)
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(x, peakY),
                        size = Size(barW, 3.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            }

            VisualizerMode.CIRCULAR_HALO -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = (size.height * 0.22f) * (0.85f + 0.35f * bassAvg)
                // Shockwave outer glow rings
                drawCircle(
                    color = primaryColor.copy(alpha = (0.18f * bassAvg).coerceIn(0.05f, 0.35f)),
                    radius = baseRadius * 1.75f,
                    center = center
                )
                drawCircle(
                    color = secondaryColor.copy(alpha = 0.35f),
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )
                val spikes = 32
                for (i in 0 until spikes) {
                    val angleRad = (i.toFloat() / spikes) * 2f * PI.toFloat() + (phase * 0.25f)
                    val spikeLen = (size.height * 0.26f) * currentLevels[i % barCount]
                    val start = Offset(
                        center.x + cos(angleRad) * baseRadius,
                        center.y + sin(angleRad) * baseRadius
                    )
                    val end = Offset(
                        center.x + cos(angleRad) * (baseRadius + spikeLen),
                        center.y + sin(angleRad) * (baseRadius + spikeLen)
                    )
                    drawLine(
                        color = if (i % 2 == 0) primaryColor else secondaryColor,
                        start = start,
                        end = end,
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            VisualizerMode.DUAL_WAVE -> {
                val pathPrimary = Path()
                val pathSecondary = Path()
                val midY = size.height / 2f
                val stepX = size.width / (barCount - 1)

                for (i in 0 until barCount) {
                    val x = i * stepX
                    val amp = currentLevels[i] * (size.height * 0.44f)
                    val wave1Y = midY + sin(phase + i * 0.35f) * amp
                    val wave2Y = midY + cos(phase * 1.3f - i * 0.30f) * (amp * 0.8f)
                    if (i == 0) {
                        pathPrimary.moveTo(x, wave1Y)
                        pathSecondary.moveTo(x, wave2Y)
                    } else {
                        pathPrimary.lineTo(x, wave1Y)
                        pathSecondary.lineTo(x, wave2Y)
                    }
                }
                drawPath(
                    path = pathSecondary,
                    color = secondaryColor.copy(alpha = 0.75f),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
                drawPath(
                    path = pathPrimary,
                    color = primaryColor,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            VisualizerMode.BEAT_PARTICLES -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                for (i in 0 until barCount) {
                    val lvl = currentLevels[i]
                    val angle = (i * 137.5f + slowPhase * 1.5f) * (PI.toFloat() / 180f)
                    val dist = (size.width * 0.42f) * ((i.toFloat() / barCount) * 0.65f + 0.35f * lvl)
                    val px = center.x + cos(angle) * dist
                    val py = center.y + sin(angle) * (dist * 0.36f)
                    val radius = (2.5f + 6.5f * lvl).dp.toPx() * 0.5f
                    drawCircle(
                        color = if (i % 2 == 0) primaryColor.copy(alpha = 0.85f) else secondaryColor.copy(alpha = 0.85f),
                        radius = radius,
                        center = Offset(px.coerceIn(0f, size.width), py.coerceIn(0f, size.height))
                    )
                }
            }

            VisualizerMode.VINYL_DECK -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                val discRadius = size.height * 0.44f
                // Outer reactive neon ring
                drawCircle(
                    color = primaryColor.copy(alpha = 0.35f + 0.45f * bassAvg),
                    radius = discRadius + 5.dp.toPx() * bassAvg,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                // Vinyl black disc
                drawCircle(
                    color = Color(0xFF121216),
                    radius = discRadius,
                    center = center
                )
                // Grooves
                for (g in 1..4) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.12f),
                        radius = discRadius * (0.35f + g * 0.14f),
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                // Rotating shine highlight
                val rotRad = (if (isPlaying) slowPhase else 0f) * (PI.toFloat() / 180f)
                val shineEnd = Offset(
                    center.x + cos(rotRad) * discRadius,
                    center.y + sin(rotRad) * discRadius
                )
                drawLine(
                    color = secondaryColor.copy(alpha = 0.65f),
                    start = center,
                    end = shineEnd,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
                // Center label
                drawCircle(
                    color = primaryColor,
                    radius = discRadius * 0.28f,
                    center = center
                )
                drawCircle(
                    color = Color.Black,
                    radius = discRadius * 0.08f,
                    center = center
                )
            }

            VisualizerMode.LED_MATRIX -> {
                val cols = 20
                val rows = 8
                val gap = 3.dp.toPx()
                val cellW = (size.width - (cols - 1) * gap) / cols
                val cellH = (size.height - (rows - 1) * gap) / rows

                for (c in 0 until cols) {
                    val lvl = currentLevels[(c * barCount) / cols]
                    val activeRows = (lvl * rows).toInt().coerceIn(1, rows)
                    for (r in 0 until activeRows) {
                        val x = c * (cellW + gap)
                        val y = size.height - (r + 1) * (cellH + gap)
                        val cellColor = when {
                            r >= rows - 2 -> secondaryColor
                            r >= rows / 2 -> primaryColor
                            else -> primaryColor.copy(alpha = 0.7f)
                        }
                        drawRoundRect(
                            color = cellColor,
                            topLeft = Offset(x, y.coerceAtLeast(0f)),
                            size = Size(cellW, cellH),
                            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                        )
                    }
                }
            }

            VisualizerMode.AURORA_WAVES -> {
                val steps = 40
                for (layer in 0 until 3) {
                    val path = Path()
                    val baseY = size.height * (0.50f + 0.12f * layer)
                    path.moveTo(0f, size.height)
                    for (s in 0..steps) {
                        val x = size.width * s / steps
                        val idx = ((s.toFloat() / steps) * (barCount - 1)).toInt().coerceIn(0, barCount - 1)
                        val amp = size.height * (0.12f + 0.30f * currentLevels[idx])
                        val y = baseY -
                            amp * (0.6f + 0.4f * sin(t * (1.1f + layer * 0.5f) + s * 0.32f + layer * 1.7f)) -
                            amp * 0.35f * sin(s * 0.17f - t * 0.8f)
                        path.lineTo(x, y.coerceIn(0f, size.height))
                    }
                    path.lineTo(size.width, size.height)
                    path.close()
                    val c = when (layer) {
                        0 -> primaryColor
                        1 -> secondaryColor
                        else -> mixColor(primaryColor, secondaryColor, 0.5f)
                    }
                    drawPath(
                        path = path,
                        brush = Brush.verticalGradient(
                            colors = listOf(c.copy(alpha = 0.65f), c.copy(alpha = 0.04f)),
                            startY = 0f,
                            endY = size.height
                        )
                    )
                }
            }

            VisualizerMode.STARFIELD_WARP -> {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val maxR = size.width * 0.55f
                val squash = size.height / size.width * 1.9f
                for (i in 0 until 70) {
                    val z = fract01(i * 0.0713f + driver.travel * 0.22f)
                    val ang = i * 2.39996f
                    val z0 = (z - 0.03f - 0.07f * bassAvg).coerceAtLeast(0f)
                    val r1 = z * z * maxR
                    val r0 = z0 * z0 * maxR
                    val p0 = Offset(cx + cos(ang) * r0, cy + sin(ang) * r0 * squash)
                    val p1 = Offset(cx + cos(ang) * r1, cy + sin(ang) * r1 * squash)
                    val col = if (i % 3 == 0) secondaryColor else primaryColor
                    drawLine(
                        color = col.copy(alpha = (z * 1.2f).coerceIn(0.05f, 1f)),
                        start = p0,
                        end = p1,
                        strokeWidth = (0.8f + 2.2f * z).dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
                val coreR = (3f + 4f * bassAvg).dp.toPx() + 10.dp.toPx() * driver.beat
                drawCircle(
                    color = Color.White.copy(alpha = 0.55f),
                    radius = coreR,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = primaryColor.copy(alpha = (0.18f + 0.3f * driver.beat).coerceIn(0f, 1f)),
                    radius = 22.dp.toPx() * (0.6f + driver.beat),
                    center = Offset(cx, cy)
                )
            }

            VisualizerMode.FIRE_EQ -> {
                val cols = 22
                val gap = 2.dp.toPx()
                val cw = (size.width - gap * (cols - 1)) / cols
                val base = size.height
                for (c in 0 until cols) {
                    val lvl = currentLevels[(c * (barCount - 1)) / (cols - 1)]
                    val flick = 0.86f + 0.14f * sin(t * 13f + c * 1.9f)
                    val fh = size.height * (0.15f + 0.85f * lvl) * flick
                    val x = c * (cw + gap)
                    val sway = sin(t * 5f + c * 0.9f) * cw * 0.45f
                    val outer = Path()
                    outer.moveTo(x, base)
                    outer.cubicTo(
                        x, base - fh * 0.45f,
                        x + cw * 0.15f + sway * 0.4f, base - fh * 0.75f,
                        x + cw * 0.5f + sway, base - fh
                    )
                    outer.cubicTo(
                        x + cw * 0.85f + sway * 0.4f, base - fh * 0.75f,
                        x + cw, base - fh * 0.45f,
                        x + cw, base
                    )
                    outer.close()
                    drawPath(
                        path = outer,
                        brush = Brush.verticalGradient(
                            colors = listOf(secondaryColor, primaryColor, primaryColor.copy(alpha = 0.5f)),
                            startY = base - fh,
                            endY = base
                        )
                    )
                    val ih = fh * 0.55f
                    val inner = Path()
                    inner.moveTo(x + cw * 0.2f, base)
                    inner.cubicTo(
                        x + cw * 0.2f, base - ih * 0.5f,
                        x + cw * 0.3f + sway * 0.3f, base - ih * 0.8f,
                        x + cw * 0.5f + sway * 0.6f, base - ih
                    )
                    inner.cubicTo(
                        x + cw * 0.7f + sway * 0.3f, base - ih * 0.8f,
                        x + cw * 0.8f, base - ih * 0.5f,
                        x + cw * 0.8f, base
                    )
                    inner.close()
                    drawPath(
                        path = inner,
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.White.copy(alpha = 0.9f), secondaryColor.copy(alpha = 0.6f)),
                            startY = base - ih,
                            endY = base
                        )
                    )
                }
            }

            VisualizerMode.LIQUID_BLOB -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseR = size.height * 0.30f * (1f + 0.25f * driver.beat)
                val pts = 48
                val raw = FloatArray(pts)
                for (i in 0 until pts) {
                    val j = if (i <= pts / 2) i else pts - i
                    val lv = currentLevels[(j * (barCount - 1)) / (pts / 2)]
                    raw[i] = baseR * (0.85f + 0.65f * lv) + baseR * 0.08f * sin(i * 0.9f + t * 2.3f)
                }
                val blob = Path()
                for (i in 0 until pts) {
                    val r = (raw[(i + pts - 1) % pts] + raw[i] * 2f + raw[(i + 1) % pts]) / 4f
                    val a = (i.toFloat() / pts) * 2f * PI.toFloat() + t * 0.4f
                    val px = center.x + cos(a) * r * 1.9f
                    val py = center.y + sin(a) * r
                    if (i == 0) blob.moveTo(px, py) else blob.lineTo(px, py)
                }
                blob.close()
                drawPath(
                    path = blob,
                    brush = Brush.radialGradient(
                        colors = listOf(secondaryColor, primaryColor.copy(alpha = 0.85f)),
                        center = center,
                        radius = baseR * 3.2f
                    )
                )
                drawPath(
                    path = blob,
                    color = Color.White.copy(alpha = 0.55f),
                    style = Stroke(width = 1.5.dp.toPx())
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.35f),
                    radius = baseR * 0.22f,
                    center = Offset(center.x - baseR * 0.5f, center.y - baseR * 0.35f)
                )
            }

            VisualizerMode.LASER_GRID -> {
                val cx = size.width / 2f
                val horizon = size.height * 0.42f
                val lineCol = primaryColor.copy(alpha = 0.55f)
                for (j in -8..8) {
                    val xb = cx + j * (size.width / 9f)
                    val xt = cx + j * (size.width / 70f)
                    drawLine(
                        color = lineCol,
                        start = Offset(xt, horizon),
                        end = Offset(xb, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                for (k in 0 until 6) {
                    val p = fract01(k / 6f + driver.travel * 0.12f)
                    val y = horizon + (size.height - horizon) * p * p
                    drawLine(
                        color = secondaryColor.copy(alpha = 0.2f + 0.5f * p),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = (0.6f + 1.4f * p).dp.toPx()
                    )
                }
                val bw = size.width / barCount
                for (i in 0 until barCount) {
                    val bh = horizon * 0.95f * currentLevels[i]
                    drawRect(
                        color = if (i % 2 == 0) primaryColor else secondaryColor,
                        topLeft = Offset(i * bw + 1.dp.toPx(), horizon - bh),
                        size = Size(bw - 2.dp.toPx(), bh)
                    )
                }
                for (l in 0 until 4) {
                    val ang = sin(t * (0.9f + l * 0.37f) + l * 1.9f) * 0.9f
                    val laserCol = if (l % 2 == 0) secondaryColor else primaryColor
                    drawLine(
                        color = laserCol.copy(alpha = (0.25f + 0.55f * driver.beat).coerceIn(0f, 1f)),
                        start = Offset(cx, horizon),
                        end = Offset(cx + sin(ang) * size.width * 0.6f, 0f),
                        strokeWidth = 1.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            VisualizerMode.RIPPLE_RINGS -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                for (k in 0 until 5) {
                    val p = fract01(k / 5f + driver.travel * 0.3f)
                    val rx = p * size.width * 0.5f
                    val ry = p * size.height * 0.5f
                    val ringCol = if (k % 2 == 0) primaryColor else secondaryColor
                    drawOval(
                        color = ringCol.copy(alpha = ((1f - p) * (0.35f + 0.65f * bassAvg)).coerceIn(0f, 1f)),
                        topLeft = Offset(center.x - rx, center.y - ry),
                        size = Size(rx * 2f, ry * 2f),
                        style = Stroke(width = (1.5f + 3f * bassAvg).dp.toPx())
                    )
                }
                val coreR = (12f + 16f * (bassAvg + driver.beat * 0.6f)).dp.toPx()
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            primaryColor.copy(alpha = 0.6f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = coreR
                    ),
                    radius = coreR,
                    center = center
                )
            }

            VisualizerMode.MIRROR_SPECTRUM -> {
                val midY = size.height / 2f
                val space = 2.dp.toPx()
                val barW = (size.width - (barCount - 1) * space) / barCount
                for (i in 0 until barCount) {
                    val h = size.height * 0.46f * currentLevels[i]
                    val x = i * (barW + space)
                    val c = mixColor(primaryColor, secondaryColor, i / (barCount - 1f))
                    drawRoundRect(
                        color = c,
                        topLeft = Offset(x, midY - h),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                    drawRoundRect(
                        color = c.copy(alpha = 0.35f),
                        topLeft = Offset(x, midY),
                        size = Size(barW, h * 0.8f),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
                drawLine(
                    color = Color.White.copy(alpha = 0.5f),
                    start = Offset(0f, midY),
                    end = Offset(size.width, midY),
                    strokeWidth = 1.dp.toPx()
                )
            }

            VisualizerMode.DNA_HELIX -> {
                val midY = size.height / 2f
                val stepX = size.width / (barCount - 1)
                for (i in 0 until barCount) {
                    val x = i * stepX
                    val ph = t * 2.4f + i * 0.5f
                    val amp = size.height * 0.40f * (0.40f + 0.60f * currentLevels[i])
                    val s = sin(ph)
                    val y1 = midY + s * amp
                    val y2 = midY - s * amp
                    val depth = cos(ph)
                    val front = (depth + 1f) / 2f
                    drawLine(
                        color = Color.White.copy(alpha = 0.18f),
                        start = Offset(x, y1),
                        end = Offset(x, y2),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawCircle(
                        color = primaryColor.copy(alpha = 0.55f + 0.45f * front),
                        radius = (2.2f + 1.8f * front).dp.toPx(),
                        center = Offset(x, y1)
                    )
                    drawCircle(
                        color = secondaryColor.copy(alpha = 0.55f + 0.45f * (1f - front)),
                        radius = (2.2f + 1.8f * (1f - front)).dp.toPx(),
                        center = Offset(x, y2)
                    )
                }
            }
        }
    }
}
