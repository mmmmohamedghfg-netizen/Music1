package com.musicwave.pro.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val contentUri: Uri,
    val albumArtUri: Uri?,
    val folderName: String,
    val dateAdded: Long
)

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>,
    val createdAt: Long = System.currentTimeMillis()
)

enum class SortOption(val labelAr: String) {
    TITLE("الاسم"),
    ARTIST("الفنان"),
    DURATION("المدة"),
    DATE_ADDED("الأحدث")
}

enum class RepeatState {
    OFF, ALL, ONE
}
