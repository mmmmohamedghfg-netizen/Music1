package com.musicwave.pro.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AudioSessionBridge {
    private val _audioSessionId = MutableStateFlow(0)
    val audioSessionId: StateFlow<Int> = _audioSessionId.asStateFlow()

    fun updateAudioSessionId(sessionId: Int) {
        if (sessionId > 0 && _audioSessionId.value != sessionId) {
            _audioSessionId.value = sessionId
        }
    }
}
