package com.musicwave.pro.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.musicwave.pro.model.AppThemeType
import com.musicwave.pro.model.VisualizerMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class ThemeIconPack(
    val headerBadge: ImageVector,
    val tabSongs: ImageVector,
    val tabPlaylists: ImageVector,
    val tabFavorites: ImageVector,
    val tabFolders: ImageVector,
    val favActive: ImageVector,
    val favInactive: ImageVector,
    val playFilled: ImageVector,
    val pauseFilled: ImageVector,
    val equalizer: ImageVector,
    val artworkCenter: ImageVector
)

data class ThemeStyleSpec(
    val type: AppThemeType,
    val bgDark: Color,
    val bgTopGradient: Color,
    val cardColor: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val cardShape: Shape,
    val buttonShape: Shape,
    val miniPlayerShape: Shape,
    val artworkShape: Shape,
    val cardBorderWidth: Dp,
    val isCircularArtwork: Boolean,
    val icons: ThemeIconPack
)

fun resolveThemeStyle(theme: AppThemeType): ThemeStyleSpec {
    return when (theme) {
        AppThemeType.NEON_CYBER -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF0B0C14),
            bgTopGradient = Color(0xFF191B34),
            cardColor = Color(0xFF17192B),
            accentPrimary = Color(0xFF00E5FF),
            accentSecondary = Color(0xFFFF2A85),
            textPrimary = Color(0xFFF5F7FF),
            textSecondary = Color(0xFF9EA4C8),
            cardShape = RoundedCornerShape(16.dp),
            buttonShape = RoundedCornerShape(12.dp),
            miniPlayerShape = RoundedCornerShape(18.dp),
            artworkShape = RoundedCornerShape(32.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.GraphicEq,
                tabSongs = Icons.Default.LibraryMusic,
                tabPlaylists = Icons.Default.QueueMusic,
                tabFavorites = Icons.Default.Favorite,
                tabFolders = Icons.Default.Folder,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.MusicNote
            )
        )

        AppThemeType.LA_CASA_RED -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF09090B),
            bgTopGradient = Color(0xFF2B070B),
            cardColor = Color(0xFF181214),
            accentPrimary = Color(0xFFE50914),
            accentSecondary = Color(0xFFFFB703),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFB8A9AC),
            cardShape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp, topEnd = 4.dp, bottomStart = 4.dp),
            buttonShape = CutCornerShape(10.dp),
            miniPlayerShape = CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp),
            artworkShape = CutCornerShape(28.dp),
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.TheaterComedy,
                tabSongs = Icons.Default.Audiotrack,
                tabPlaylists = Icons.Default.FeaturedPlayList,
                tabFavorites = Icons.Default.LocalFireDepartment,
                tabFolders = Icons.Default.Inventory2,
                favActive = Icons.Default.LocalFireDepartment,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayArrow,
                pauseFilled = Icons.Default.Pause,
                equalizer = Icons.Default.Tune,
                artworkCenter = Icons.Default.Shield
            )
        )

        AppThemeType.ROYAL_GOLD -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF0E0C08),
            bgTopGradient = Color(0xFF282011),
            cardColor = Color(0xFF1C170E),
            accentPrimary = Color(0xFFFFD700),
            accentSecondary = Color(0xFFFF8C00),
            textPrimary = Color(0xFFFFFBF0),
            textSecondary = Color(0xFFC8B88A),
            cardShape = RoundedCornerShape(topStart = 24.dp, bottomEnd = 24.dp, topEnd = 8.dp, bottomStart = 8.dp),
            buttonShape = RoundedCornerShape(50),
            miniPlayerShape = RoundedCornerShape(26.dp),
            artworkShape = CircleShape,
            cardBorderWidth = 1.5.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.WorkspacePremium,
                tabSongs = Icons.Default.Stars,
                tabPlaylists = Icons.Default.AutoStories,
                tabFavorites = Icons.Default.Diamond,
                tabFolders = Icons.Default.FolderSpecial,
                favActive = Icons.Default.Grade,
                favInactive = Icons.Default.StarBorder,
                playFilled = Icons.Default.PlayCircle,
                pauseFilled = Icons.Default.PauseCircle,
                equalizer = Icons.Default.AutoGraph,
                artworkCenter = Icons.Default.WorkspacePremium
            )
        )

        AppThemeType.SHAABI_FESTIVAL -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF11071F),
            bgTopGradient = Color(0xFF330C4D),
            cardColor = Color(0xFF211038),
            accentPrimary = Color(0xFFFF6D00),
            accentSecondary = Color(0xFFD500F9),
            textPrimary = Color(0xFFFFF8F0),
            textSecondary = Color(0xFFC7A4E0),
            cardShape = CutCornerShape(12.dp),
            buttonShape = RoundedCornerShape(16.dp),
            miniPlayerShape = RoundedCornerShape(22.dp),
            artworkShape = CutCornerShape(24.dp),
            cardBorderWidth = 2.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Speaker,
                tabSongs = Icons.Default.SpeakerGroup,
                tabPlaylists = Icons.Default.QueuePlayNext,
                tabFavorites = Icons.Default.Bolt,
                tabFolders = Icons.Default.Topic,
                favActive = Icons.Default.Bolt,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.SurroundSound,
                artworkCenter = Icons.Default.Campaign
            )
        )

        AppThemeType.RETRO_VINYL -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF14110E),
            bgTopGradient = Color(0xFF2E2318),
            cardColor = Color(0xFF241D17),
            accentPrimary = Color(0xFFFFB300),
            accentSecondary = Color(0xFFFF5722),
            textPrimary = Color(0xFFFAF0E4),
            textSecondary = Color(0xFFB8A28B),
            cardShape = RoundedCornerShape(28.dp),
            buttonShape = RoundedCornerShape(50),
            miniPlayerShape = RoundedCornerShape(50),
            artworkShape = CircleShape,
            cardBorderWidth = 1.dp,
            isCircularArtwork = true,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.Album,
                tabSongs = Icons.Default.Radio,
                tabPlaylists = Icons.Default.Subscriptions,
                tabFavorites = Icons.Default.Favorite,
                tabFolders = Icons.Default.Storage,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.SettingsInputComponent,
                artworkCenter = Icons.Default.Album
            )
        )

        AppThemeType.EMERALD_GLASS -> ThemeStyleSpec(
            type = theme,
            bgDark = Color(0xFF061317),
            bgTopGradient = Color(0xFF0B2E36),
            cardColor = Color(0xFF0F242A),
            accentPrimary = Color(0xFF00E676),
            accentSecondary = Color(0xFF00B0FF),
            textPrimary = Color(0xFFEFFFF6),
            textSecondary = Color(0xFF8AB8B0),
            cardShape = RoundedCornerShape(22.dp),
            buttonShape = RoundedCornerShape(18.dp),
            miniPlayerShape = RoundedCornerShape(24.dp),
            artworkShape = RoundedCornerShape(40.dp),
            cardBorderWidth = 1.dp,
            isCircularArtwork = false,
            icons = ThemeIconPack(
                headerBadge = Icons.Default.AutoAwesome,
                tabSongs = Icons.Default.Headphones,
                tabPlaylists = Icons.Default.PlaylistPlay,
                tabFavorites = Icons.Default.Spa,
                tabFolders = Icons.Default.SnippetFolder,
                favActive = Icons.Default.Favorite,
                favInactive = Icons.Default.FavoriteBorder,
                playFilled = Icons.Default.PlayCircleFilled,
                pauseFilled = Icons.Default.PauseCircleFilled,
                equalizer = Icons.Default.Equalizer,
                artworkCenter = Icons.Default.Headset
            )
        )
    }
}

@Composable
fun HyperRealisticVisualizer(
    mode: VisualizerMode,
    isPlaying: Boolean,
    realBars: List<Float>,
    primaryColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
        .fillMaxWidth(0.92f)
        .height(92.dp)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "vis_engine")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 720, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )
    val slowPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "slowPhase"
    )

    // Peak hold memory for gravity peak caps
    val peakHold = remember { FloatArray(32) { 0.15f } }

    Canvas(modifier = modifier) {
        val barCount = 32
        val currentLevels = FloatArray(barCount)

        for (i in 0 until barCount) {
            val level = if (!isPlaying) {
                0.10f + 0.03f * sin(i * 0.4f)
            } else if (realBars.size >= barCount) {
                realBars[i].coerceIn(0.10f, 1.0f)
            } else {
                // Multi-harmonic realistic beat synthesis when microphone permission is off
                val subBass = if (i < 6) 0.32f * abs(sin(phase * 2f)) else 0f
                val midPunch = 0.42f * abs(sin(phase * 1.5f + i * 0.38f))
                val highSparkle = 0.24f * abs(cos(phase * 3f - i * 0.65f))
                (0.12f + subBass + midPunch + highSparkle).coerceIn(0.12f, 0.98f)
            }
            currentLevels[i] = level
            if (level >= peakHold[i]) {
                peakHold[i] = level
            } else {
                peakHold[i] = (peakHold[i] - 0.018f).coerceAtLeast(level)
            }
        }

        val bassAvg = (currentLevels[0] + currentLevels[1] + currentLevels[2] + currentLevels[3]) / 4f

        when (mode) {
            VisualizerMode.SPECTRUM_PEAKS -> {
                val space = 4.dp.toPx()
                val barW = (size.width - (barCount - 1) * space) / barCount
                for (i in 0 until barCount) {
                    val h = size.height * 0.85f * currentLevels[i]
                    val x = i * (barW + space)
                    val topY = size.height - h
                    val brush = Brush.verticalGradient(
                        colors = listOf(secondaryColor, primaryColor, primaryColor.copy(alpha = 0.35f)),
                        startY = topY,
                        endY = size.height
                    )
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(x, topY),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                    // Floating gravity peak cap
                    val peakY = (size.height - size.height * 0.85f * peakHold[i] - 4.dp.toPx()).coerceAtLeast(0f)
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(x, peakY),
                        size = Size(barW, 3.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            }

            VisualizerMode.CIRCULAR_HALO -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = (size.height * 0.22f) * (0.85f + 0.35f * bassAvg)
                // Shockwave outer glow rings
                drawCircle(
                    color = primaryColor.copy(alpha = (0.18f * bassAvg).coerceIn(0.05f, 0.35f)),
                    radius = baseRadius * 1.75f,
                    center = center
                )
                drawCircle(
                    color = secondaryColor.copy(alpha = 0.35f),
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )
                val spikes = 32
                for (i in 0 until spikes) {
                    val angleRad = (i.toFloat() / spikes) * 2f * PI.toFloat() + (phase * 0.25f)
                    val spikeLen = (size.height * 0.26f) * currentLevels[i % barCount]
                    val start = Offset(
                        center.x + cos(angleRad) * baseRadius,
                        center.y + sin(angleRad) * baseRadius
                    )
                    val end = Offset(
                        center.x + cos(angleRad) * (baseRadius + spikeLen),
                        center.y + sin(angleRad) * (baseRadius + spikeLen)
                    )
                    drawLine(
                        color = if (i % 2 == 0) primaryColor else secondaryColor,
                        start = start,
                        end = end,
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            VisualizerMode.DUAL_WAVE -> {
                val pathPrimary = Path()
                val pathSecondary = Path()
                val midY = size.height / 2f
                val stepX = size.width / (barCount - 1)

                for (i in 0 until barCount) {
                    val x = i * stepX
                    val amp = currentLevels[i] * (size.height * 0.44f)
                    val wave1Y = midY + sin(phase + i * 0.35f) * amp
                    val wave2Y = midY + cos(phase * 1.3f - i * 0.30f) * (amp * 0.8f)
                    if (i == 0) {
                        pathPrimary.moveTo(x, wave1Y)
                        pathSecondary.moveTo(x, wave2Y)
                    } else {
                        pathPrimary.lineTo(x, wave1Y)
                        pathSecondary.lineTo(x, wave2Y)
                    }
                }
                drawPath(
                    path = pathSecondary,
                    color = secondaryColor.copy(alpha = 0.75f),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
                drawPath(
                    path = pathPrimary,
                    color = primaryColor,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            VisualizerMode.BEAT_PARTICLES -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                for (i in 0 until barCount) {
                    val lvl = currentLevels[i]
                    val angle = (i * 137.5f + slowPhase * 1.5f) * (PI.toFloat() / 180f)
                    val dist = (size.width * 0.42f) * ((i.toFloat() / barCount) * 0.65f + 0.35f * lvl)
                    val px = center.x + cos(angle) * dist
                    val py = center.y + sin(angle) * (dist * 0.36f)
                    val radius = (2.5f + 6.5f * lvl).dp.toPx() * 0.5f
                    drawCircle(
                        color = if (i % 2 == 0) primaryColor.copy(alpha = 0.85f) else secondaryColor.copy(alpha = 0.85f),
                        radius = radius,
                        center = Offset(px.coerceIn(0f, size.width), py.coerceIn(0f, size.height))
                    )
                }
            }

            VisualizerMode.VINYL_DECK -> {
                val center = Offset(size.width / 2f, size.height / 2f)
                val discRadius = size.height * 0.44f
                // Outer reactive neon ring
                drawCircle(
                    color = primaryColor.copy(alpha = 0.35f + 0.45f * bassAvg),
                    radius = discRadius + 5.dp.toPx() * bassAvg,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                // Vinyl black disc
                drawCircle(
                    color = Color(0xFF121216),
                    radius = discRadius,
                    center = center
                )
                // Grooves
                for (g in 1..4) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.12f),
                        radius = discRadius * (0.35f + g * 0.14f),
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                // Rotating shine highlight
                val rotRad = (if (isPlaying) slowPhase else 0f) * (PI.toFloat() / 180f)
                val shineEnd = Offset(
                    center.x + cos(rotRad) * discRadius,
                    center.y + sin(rotRad) * discRadius
                )
                drawLine(
                    color = secondaryColor.copy(alpha = 0.65f),
                    start = center,
                    end = shineEnd,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
                // Center label
                drawCircle(
                    color = primaryColor,
                    radius = discRadius * 0.28f,
                    center = center
                )
                drawCircle(
                    color = Color.Black,
                    radius = discRadius * 0.08f,
                    center = center
                )
            }

            VisualizerMode.LED_MATRIX -> {
                val cols = 20
                val rows = 8
                val gap = 3.dp.toPx()
                val cellW = (size.width - (cols - 1) * gap) / cols
                val cellH = (size.height - (rows - 1) * gap) / rows

                for (c in 0 until cols) {
                    val lvl = currentLevels[(c * barCount) / cols]
                    val activeRows = (lvl * rows).toInt().coerceIn(1, rows)
                    for (r in 0 until activeRows) {
                        val x = c * (cellW + gap)
                        val y = size.height - (r + 1) * (cellH + gap)
                        val cellColor = when {
                            r >= rows - 2 -> secondaryColor
                            r >= rows / 2 -> primaryColor
                            else -> primaryColor.copy(alpha = 0.7f)
                        }
                        drawRoundRect(
                            color = cellColor,
                            topLeft = Offset(x, y.coerceAtLeast(0f)),
                            size = Size(cellW, cellH),
                            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}
