package com.musicwave.pro.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.musicwave.pro.model.AppThemeType
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.RepeatState
import com.musicwave.pro.model.Song
import com.musicwave.pro.model.SortOption
import com.musicwave.pro.model.VisualizerMode
import com.musicwave.pro.viewmodel.MusicViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicWaveApp(
    viewModel: MusicViewModel,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onOpenSystemEqualizer: () -> Unit
) {
    val context = LocalContext.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val allSongs by viewModel.allSongs.collectAsState()
        val currentQueue by viewModel.currentQueue.collectAsState()
        val currentSong by viewModel.currentSong.collectAsState()
        val isPlaying by viewModel.isPlaying.collectAsState()
        val currentPosition by viewModel.currentPosition.collectAsState()
        val duration by viewModel.duration.collectAsState()
        val shuffleEnabled by viewModel.shuffleEnabled.collectAsState()
        val repeatState by viewModel.repeatState.collectAsState()
        val favorites by viewModel.favorites.collectAsState()
        val playlists by viewModel.playlists.collectAsState()
        val searchQuery by viewModel.searchQuery.collectAsState()
        val sortOption by viewModel.sortOption.collectAsState()
        val playbackSpeed by viewModel.playbackSpeed.collectAsState()
        val bassStrength by viewModel.bassStrength.collectAsState()
        val eqBands by viewModel.eqBands.collectAsState()
        val activePresetId by viewModel.activePresetId.collectAsState()
        val visualizerBars by viewModel.visualizerBars.collectAsState()
        val sleepTimerLeft by viewModel.sleepTimerMinutesLeft.collectAsState()
        val currentLyrics by viewModel.currentLyrics.collectAsState()
        val selectedTheme by viewModel.selectedTheme.collectAsState()
        val visualizerMode by viewModel.visualizerMode.collectAsState()

        val themeStyle = remember(selectedTheme) { resolveThemeStyle(selectedTheme) }

        var selectedTab by remember { mutableIntStateOf(0) }
        var showFullPlayer by remember { mutableStateOf(false) }
        var showCreatePlaylistDialog by remember { mutableStateOf(false) }
        var songToAddToPlaylist by remember { mutableStateOf<Song?>(null) }
        var songForOptionsMenu by remember { mutableStateOf<Song?>(null) }
        var activePlaylistId by remember { mutableStateOf<String?>(null) }
        var showAudioSettingsSheet by remember { mutableStateOf(false) }
        var showThemesAndVisualsDialog by remember { mutableStateOf(false) }
        var showQueueDialog by remember { mutableStateOf(false) }
        var showLyricsDialog by remember { mutableStateOf(false) }

        val activePlaylist = remember(playlists, activePlaylistId) {
            playlists.find { it.id == activePlaylistId }
        }

        val filteredSongs = remember(allSongs, searchQuery) {
            if (searchQuery.isBlank()) allSongs
            else allSongs.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.artist.contains(searchQuery, ignoreCase = true) ||
                    it.album.contains(searchQuery, ignoreCase = true)
            }
        }

        Scaffold(
            containerColor = themeStyle.bgDark,
            topBar = {
                TopHeader(
                    style = themeStyle,
                    searchQuery = searchQuery,
                    onSearchChange = viewModel::updateSearchQuery,
                    sleepTimerLeft = sleepTimerLeft,
                    onOpenThemes = { showThemesAndVisualsDialog = true },
                    onOpenSettings = { showAudioSettingsSheet = true },
                    onRefresh = { viewModel.loadSongs() }
                )
            },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (currentSong != null) {
                        MiniPlayerBar(
                            style = themeStyle,
                            song = currentSong!!,
                            isPlaying = isPlaying,
                            progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f,
                            onTogglePlay = viewModel::togglePlayPause,
                            onNext = viewModel::playNext,
                            onOpenQueue = { showQueueDialog = true },
                            onClick = { showFullPlayer = true }
                        )
                    }
                    NavigationBar(
                        containerColor = themeStyle.cardColor,
                        tonalElevation = 8.dp
                    ) {
                        val tabs = listOf(
                            Triple("الأغاني", themeStyle.icons.tabSongs, 0),
                            Triple("قوائم التشغيل", themeStyle.icons.tabPlaylists, 1),
                            Triple("المفضلة", themeStyle.icons.tabFavorites, 2),
                            Triple("المجلدات", themeStyle.icons.tabFolders, 3)
                        )
                        tabs.forEach { (title, icon, index) ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = {
                                    selectedTab = index
                                    activePlaylistId = null
                                },
                                icon = { Icon(icon, contentDescription = title) },
                                label = { Text(title, fontWeight = FontWeight.SemiBold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = themeStyle.accentPrimary,
                                    selectedTextColor = themeStyle.accentPrimary,
                                    unselectedIconColor = themeStyle.textSecondary,
                                    unselectedTextColor = themeStyle.textSecondary,
                                    indicatorColor = themeStyle.accentPrimary.copy(alpha = 0.16f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!hasPermission) {
                    PermissionPromptCard(style = themeStyle, onRequestPermission = onRequestPermission)
                } else {
                    when (selectedTab) {
                        0 -> AllSongsTab(
                            style = themeStyle,
                            songs = filteredSongs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            favorites = favorites,
                            sortOption = sortOption,
                            onSortChange = viewModel::updateSortOption,
                            onSongClick = { song -> viewModel.playSongFromQueue(song, filteredSongs) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onMoreOptions = { songForOptionsMenu = it },
                            onShuffleAll = {
                                if (filteredSongs.isNotEmpty()) {
                                    viewModel.playSongFromQueue(filteredSongs.random(), filteredSongs.shuffled())
                                }
                            }
                        )

                        1 -> PlaylistsTab(
                            style = themeStyle,
                            playlists = playlists,
                            allSongs = allSongs,
                            activePlaylist = activePlaylist,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            favorites = favorites,
                            onSelectPlaylist = { activePlaylistId = it.id },
                            onBackToPlaylists = { activePlaylistId = null },
                            onCreateNew = { showCreatePlaylistDialog = true },
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onMoveSongInPlaylist = { plId, fromIdx, toIdx ->
                                viewModel.moveSongInPlaylist(plId, fromIdx, toIdx)
                            },
                            onRemoveSongFromPlaylist = { plId, sId ->
                                viewModel.removeSongFromPlaylist(plId, sId)
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) }
                        )

                        2 -> FavoritesTab(
                            style = themeStyle,
                            allSongs = allSongs,
                            favorites = favorites,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onMoreOptions = { songForOptionsMenu = it }
                        )

                        3 -> FoldersTab(
                            style = themeStyle,
                            allSongs = allSongs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            favorites = favorites,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onMoreOptions = { songForOptionsMenu = it }
                        )
                    }
                }
            }
        }

        // Full Now Playing Screen Overlay
        AnimatedVisibility(
            visible = showFullPlayer && currentSong != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            currentSong?.let { song ->
                NowPlayingFullScreen(
                    style = themeStyle,
                    song = song,
                    isPlaying = isPlaying,
                    currentPosition = currentPosition,
                    duration = duration,
                    shuffleEnabled = shuffleEnabled,
                    repeatState = repeatState,
                    isFavorite = favorites.contains(song.id),
                    playbackSpeed = playbackSpeed,
                    visualizerMode = visualizerMode,
                    visualizerBars = visualizerBars,
                    hasLyrics = currentLyrics.isNotBlank(),
                    onClose = { showFullPlayer = false },
                    onTogglePlay = viewModel::togglePlayPause,
                    onNext = viewModel::playNext,
                    onPrevious = viewModel::playPrevious,
                    onSeek = viewModel::seekTo,
                    onToggleShuffle = viewModel::toggleShuffle,
                    onCycleRepeat = viewModel::cycleRepeatMode,
                    onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                    onCycleVisualizer = {
                        val allModes = VisualizerMode.values()
                        val nextIdx = (allModes.indexOf(visualizerMode) + 1) % allModes.size
                        viewModel.setVisualizerMode(allModes[nextIdx])
                    },
                    onOpenThemes = { showThemesAndVisualsDialog = true },
                    onOpenOptions = { songForOptionsMenu = song },
                    onOpenQueue = { showQueueDialog = true },
                    onOpenLyrics = { showLyricsDialog = true },
                    onOpenAudioSettings = { showAudioSettingsSheet = true }
                )
            }
        }

        // Themes & Visual Effects Studio Dialog
        if (showThemesAndVisualsDialog) {
            AlertDialog(
                onDismissRequest = { showThemesAndVisualsDialog = false },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("استوديو الثيمات والمؤثرات البصرية", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Text("تُحفظ اختياراتك تلقائياً بشكل دائم", color = themeStyle.accentPrimary, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Palette, contentDescription = null, tint = themeStyle.accentPrimary)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "اختر الثيم (كل ثيم له تصميم خاص وحزمة أيقونات مستقلة):",
                            color = themeStyle.accentPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        AppThemeType.values().forEach { themeItem ->
                            val itemSpec = resolveThemeStyle(themeItem)
                            val isSelected = selectedTheme == themeItem
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(itemSpec.cardShape)
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) itemSpec.accentPrimary else itemSpec.textSecondary.copy(alpha = 0.25f),
                                        shape = itemSpec.cardShape
                                    )
                                    .clickable { viewModel.setTheme(themeItem) },
                                color = itemSpec.bgDark,
                                shape = itemSpec.cardShape
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(itemSpec.buttonShape)
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(itemSpec.accentPrimary, itemSpec.accentSecondary)
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(itemSpec.icons.headerBadge, contentDescription = null, tint = itemSpec.bgDark)
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = themeItem.titleAr,
                                            color = itemSpec.textPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = themeItem.subtitleAr,
                                            color = itemSpec.textSecondary,
                                            fontSize = 11.sp
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        // Mini preview of the theme's custom icon pack
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(itemSpec.icons.tabSongs, contentDescription = null, tint = itemSpec.accentPrimary, modifier = Modifier.size(14.dp))
                                            Icon(itemSpec.icons.tabPlaylists, contentDescription = null, tint = itemSpec.accentSecondary, modifier = Modifier.size(14.dp))
                                            Icon(itemSpec.icons.tabFavorites, contentDescription = null, tint = itemSpec.accentPrimary, modifier = Modifier.size(14.dp))
                                            Icon(itemSpec.icons.tabFolders, contentDescription = null, tint = itemSpec.accentSecondary, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "مفعل", tint = itemSpec.accentPrimary)
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = themeStyle.textSecondary.copy(alpha = 0.2f))

                        Text(
                            "المؤثر البصري المتفاعل مع الأغاني (Audio Visualizer):",
                            color = themeStyle.accentSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        VisualizerMode.values().forEach { mode ->
                            val isModeSelected = visualizerMode == mode
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(themeStyle.buttonShape)
                                    .border(
                                        width = if (isModeSelected) 1.5.dp else 0.5.dp,
                                        color = if (isModeSelected) themeStyle.accentPrimary else themeStyle.textSecondary.copy(alpha = 0.2f),
                                        shape = themeStyle.buttonShape
                                    )
                                    .clickable { viewModel.setVisualizerMode(mode) },
                                color = themeStyle.bgDark,
                                shape = themeStyle.buttonShape
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(
                                            Icons.Default.Equalizer,
                                            contentDescription = null,
                                            tint = if (isModeSelected) themeStyle.accentPrimary else themeStyle.textSecondary
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Text(
                                            text = mode.titleAr,
                                            color = if (isModeSelected) themeStyle.accentPrimary else themeStyle.textPrimary,
                                            fontWeight = if (isModeSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp
                                        )
                                    }
                                    if (isModeSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = themeStyle.accentPrimary)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showThemesAndVisualsDialog = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = themeStyle.accentPrimary,
                            contentColor = themeStyle.bgDark
                        ),
                        shape = themeStyle.buttonShape
                    ) {
                        Text("تم الحفظ", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Song Options Dialog (Share, Set as Ringtone, Add to Playlist)
        songForOptionsMenu?.let { targetSong ->
            AlertDialog(
                onDismissRequest = { songForOptionsMenu = null },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = {
                    Column {
                        Text(targetSong.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(targetSong.artist, color = themeStyle.accentPrimary, fontSize = 13.sp)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OptionRowButton(
                            style = themeStyle,
                            icon = Icons.Default.PlaylistAdd,
                            title = "إضافة إلى قائمة تشغيل",
                            tint = themeStyle.accentPrimary
                        ) {
                            songForOptionsMenu = null
                            songToAddToPlaylist = targetSong
                        }
                        OptionRowButton(
                            style = themeStyle,
                            icon = Icons.Default.Share,
                            title = "مشاركة الملف الصوتي (واتساب / بلوتوث)",
                            tint = themeStyle.textPrimary
                        ) {
                            songForOptionsMenu = null
                            viewModel.shareSong(context, targetSong)
                        }
                        OptionRowButton(
                            style = themeStyle,
                            icon = Icons.Default.RingVolume,
                            title = "تعيين كنغمة رنين للهاتف",
                            tint = themeStyle.accentSecondary
                        ) {
                            songForOptionsMenu = null
                            viewModel.setSongAsRingtone(context, targetSong)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { songForOptionsMenu = null }) {
                        Text("إغلاق", color = themeStyle.textSecondary)
                    }
                }
            )
        }

        // Playing Queue Dialog with Drag-and-Drop Reordering
        if (showQueueDialog) {
            AlertDialog(
                onDismissRequest = { showQueueDialog = false },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("طابور التشغيل الحالي (${currentQueue.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Icon(themeStyle.icons.tabPlaylists, contentDescription = null, tint = themeStyle.accentPrimary)
                        }
                        Text("اسحب من علامة (≡) لترتيب الأغاني بالسحب المباشر", color = themeStyle.textSecondary, fontSize = 11.sp)
                    }
                },
                text = {
                    if (currentQueue.isEmpty()) {
                        Text("طابور التشغيل فارغ حالياً.", color = themeStyle.textSecondary)
                    } else {
                        var draggedQueueIndex by remember { mutableStateOf<Int?>(null) }
                        var dragQueueOffsetY by remember { mutableFloatStateOf(0f) }
                        val rowHeightPx = with(LocalDensity.current) { 58.dp.toPx() }

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 380.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            itemsIndexed(currentQueue, key = { index, item -> "${item.id}_$index" }) { index, item ->
                                val isCurrent = currentSong?.id == item.id
                                val isBeingDragged = draggedQueueIndex == index
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .zIndex(if (isBeingDragged) 2f else 0f)
                                        .graphicsLayer {
                                            translationY = if (isBeingDragged) dragQueueOffsetY else 0f
                                            scaleX = if (isBeingDragged) 1.03f else 1f
                                            scaleY = if (isBeingDragged) 1.03f else 1f
                                        }
                                        .clip(themeStyle.buttonShape)
                                        .border(
                                            width = if (isBeingDragged) 1.5.dp else 0.dp,
                                            color = if (isBeingDragged) themeStyle.accentPrimary else Color.Transparent,
                                            shape = themeStyle.buttonShape
                                        )
                                        .clickable {
                                            viewModel.playSongFromQueue(item, currentQueue)
                                        },
                                    color = if (isCurrent) themeStyle.accentPrimary.copy(alpha = 0.18f) else themeStyle.bgDark
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Drag Handle
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .pointerInput(currentQueue.size) {
                                                    detectDragGestures(
                                                        onDragStart = {
                                                            draggedQueueIndex = index
                                                            dragQueueOffsetY = 0f
                                                        },
                                                        onDragEnd = {
                                                            draggedQueueIndex = null
                                                            dragQueueOffsetY = 0f
                                                        },
                                                        onDragCancel = {
                                                            draggedQueueIndex = null
                                                            dragQueueOffsetY = 0f
                                                        },
                                                        onDrag = { change, dragAmount ->
                                                            change.consume()
                                                            dragQueueOffsetY += dragAmount.y
                                                            val curIdx = draggedQueueIndex ?: return@detectDragGestures
                                                            if (dragQueueOffsetY > rowHeightPx && curIdx < currentQueue.lastIndex) {
                                                                viewModel.moveSongInQueue(curIdx, curIdx + 1)
                                                                draggedQueueIndex = curIdx + 1
                                                                dragQueueOffsetY -= rowHeightPx
                                                            } else if (dragQueueOffsetY < -rowHeightPx && curIdx > 0) {
                                                                viewModel.moveSongInQueue(curIdx, curIdx - 1)
                                                                draggedQueueIndex = curIdx - 1
                                                                dragQueueOffsetY += rowHeightPx
                                                            }
                                                        }
                                                    )
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.DragHandle,
                                                contentDescription = "اسحب للترتيب",
                                                tint = if (isBeingDragged) themeStyle.accentPrimary else themeStyle.textSecondary
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.title,
                                                color = if (isCurrent) themeStyle.accentPrimary else themeStyle.textPrimary,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = item.artist,
                                                color = themeStyle.textSecondary,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        IconButton(
                                            onClick = { viewModel.removeSongFromQueue(index) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "إزالة", tint = themeStyle.accentSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showQueueDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = themeStyle.accentPrimary, contentColor = themeStyle.bgDark),
                        shape = themeStyle.buttonShape
                    ) {
                        Text("تم", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Lyrics Viewer & Editor Dialog
        if (showLyricsDialog && currentSong != null) {
            var isEditingLyrics by remember { mutableStateOf(false) }
            var editableLyrics by remember(currentLyrics) { mutableStateOf(currentLyrics) }

            AlertDialog(
                onDismissRequest = { showLyricsDialog = false },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("كلمات الأغنية (Lyrics)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(currentSong!!.title, color = themeStyle.accentPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { isEditingLyrics = !isEditingLyrics }) {
                            Icon(
                                if (isEditingLyrics) Icons.Default.Visibility else Icons.Default.Edit,
                                contentDescription = "تعديل الكلمات",
                                tint = themeStyle.accentPrimary
                            )
                        }
                    }
                },
                text = {
                    if (isEditingLyrics) {
                        OutlinedTextField(
                            value = editableLyrics,
                            onValueChange = { editableLyrics = it },
                            label = { Text("اكتب أو الصق كلمات الأغنية هنا...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = themeStyle.accentPrimary,
                                unfocusedBorderColor = themeStyle.textSecondary,
                                focusedTextColor = themeStyle.textPrimary,
                                unfocusedTextColor = themeStyle.textPrimary
                            )
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 160.dp, max = 340.dp)
                                .clip(themeStyle.cardShape)
                                .background(themeStyle.bgDark)
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState()),
                            contentAlignment = Alignment.Center
                        ) {
                            if (currentLyrics.isBlank()) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Lyrics, contentDescription = null, tint = themeStyle.textSecondary, modifier = Modifier.size(40.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "لا توجد كلمات مضافة لهذه الأغنية بعد.\nاضغط على أيقونة القلم بالأعلى لإضافة الكلمات أو ضع ملف .lrc بنفس اسم الأغنية.",
                                        color = themeStyle.textSecondary,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                Text(
                                    text = currentLyrics,
                                    color = themeStyle.textPrimary,
                                    fontSize = 16.sp,
                                    lineHeight = 26.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (isEditingLyrics) {
                        Button(
                            onClick = {
                                viewModel.saveLyricsForCurrentSong(editableLyrics)
                                isEditingLyrics = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themeStyle.accentPrimary, contentColor = themeStyle.bgDark)
                        ) {
                            Text("حفظ الكلمات", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { showLyricsDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = themeStyle.accentPrimary, contentColor = themeStyle.bgDark)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }

        // Create Playlist Dialog
        if (showCreatePlaylistDialog) {
            var newName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showCreatePlaylistDialog = false },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                textContentColor = themeStyle.textPrimary,
                title = { Text("إنشاء قائمة تشغيل جديدة", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("اسم القائمة (مثال: مهرجانات ٢٠٢٦)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = themeStyle.accentPrimary,
                            unfocusedBorderColor = themeStyle.textSecondary,
                            focusedTextColor = themeStyle.textPrimary,
                            unfocusedTextColor = themeStyle.textPrimary
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                viewModel.createPlaylist(newName)
                                showCreatePlaylistDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = themeStyle.accentPrimary, contentColor = themeStyle.bgDark)
                    ) {
                        Text("حفظ", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreatePlaylistDialog = false }) {
                        Text("إلغاء", color = themeStyle.textSecondary)
                    }
                }
            )
        }

        // Add Song to Playlist Dialog
        songToAddToPlaylist?.let { targetSong ->
            AlertDialog(
                onDismissRequest = { songToAddToPlaylist = null },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = { Text("إضافة (${targetSong.title}) إلى قائمة", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (playlists.isEmpty()) {
                            Text("لا توجد قوائم تشغيل حالياً. أنشئ قائمة جديدة أولاً.", color = themeStyle.textSecondary)
                        } else {
                            playlists.forEach { pl ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(themeStyle.buttonShape)
                                        .clickable {
                                            viewModel.addSongToPlaylist(pl.id, targetSong.id)
                                            songToAddToPlaylist = null
                                        },
                                    color = themeStyle.bgDark
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(pl.name, color = themeStyle.textPrimary, fontWeight = FontWeight.Medium)
                                        Text("${pl.songIds.size} أغنية", color = themeStyle.accentPrimary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        songToAddToPlaylist = null
                        showCreatePlaylistDialog = true
                    }) {
                        Text("+ قائمة جديدة", color = themeStyle.accentPrimary, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { songToAddToPlaylist = null }) {
                        Text("إغلاق", color = themeStyle.textSecondary)
                    }
                }
            )
        }

        // Built-in 5-Band Equalizer, BassBoost, Speed & Sleep Timer Dialog (All Persisted)
        if (showAudioSettingsSheet) {
            val bandLabels = listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
            AlertDialog(
                onDismissRequest = { showAudioSettingsSheet = false },
                containerColor = themeStyle.cardColor,
                titleContentColor = themeStyle.textPrimary,
                title = {
                    Column {
                        Text("معادل الصوت المدمج (5-Band EQ) والمؤثرات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("جميع الإعدادات تُحفظ تلقائياً ولا تتغير عند الخروج", color = themeStyle.accentPrimary, fontSize = 11.sp)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("أوضاع الصوت الجاهزة (Presets):", color = themeStyle.accentPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(viewModel.eqPresets) { preset ->
                                FilterChip(
                                    selected = activePresetId == preset.id,
                                    onClick = { viewModel.applyEqPreset(preset) },
                                    label = { Text(preset.nameAr, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = themeStyle.accentPrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = themeStyle.accentPrimary,
                                        labelColor = themeStyle.textSecondary
                                    )
                                )
                            }
                        }

                        // 5-Band Equalizer Sliders
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(themeStyle.cardShape)
                                .background(themeStyle.bgDark)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            bandLabels.forEachIndexed { index, freqLabel ->
                                val gainMb = eqBands.getOrElse(index) { 0 }
                                val dbVal = gainMb / 100
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = freqLabel,
                                        color = themeStyle.textSecondary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.width(44.dp)
                                    )
                                    Slider(
                                        value = gainMb.toFloat(),
                                        onValueChange = { viewModel.setEqBandLevel(index, it.toInt()) },
                                        valueRange = -1500f..1500f,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(28.dp),
                                        colors = SliderDefaults.colors(
                                            thumbColor = themeStyle.accentPrimary,
                                            activeTrackColor = if (index % 2 == 0) themeStyle.accentPrimary else themeStyle.accentSecondary
                                        )
                                    )
                                    Text(
                                        text = if (dbVal >= 0) "+${dbVal}dB" else "${dbVal}dB",
                                        color = themeStyle.textPrimary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.width(42.dp),
                                        textAlign = TextAlign.End
                                    )
                                }
                            }
                        }

                        Text("تعزيز البيز المباشر (Bass Boost): ${(bassStrength / 10)}%", color = themeStyle.accentSecondary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Slider(
                            value = bassStrength.toFloat(),
                            onValueChange = { viewModel.setBassBoostStrength(it.toInt()) },
                            valueRange = 0f..1000f,
                            colors = SliderDefaults.colors(thumbColor = themeStyle.accentSecondary, activeTrackColor = themeStyle.accentSecondary)
                        )

                        Text("سرعة التشغيل: ${playbackSpeed}x", color = themeStyle.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { spd ->
                                FilterChip(
                                    selected = playbackSpeed == spd,
                                    onClick = { viewModel.setPlaybackSpeed(spd) },
                                    label = { Text("${spd}x") }
                                )
                            }
                        }

                        Text("مؤقت الإيقاف التلقائي (Sleep Timer):", color = themeStyle.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(null to "إيقاف", 15 to "15 د", 30 to "30 د", 60 to "60 د").forEach { (mins, label) ->
                                FilterChip(
                                    selected = sleepTimerLeft == mins,
                                    onClick = { viewModel.startSleepTimer(mins) },
                                    label = { Text(label) }
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onOpenSystemEqualizer,
                            modifier = Modifier.fillMaxWidth(),
                            shape = themeStyle.buttonShape
                        ) {
                            Icon(themeStyle.icons.equalizer, contentDescription = null, tint = themeStyle.accentPrimary)
                            Spacer(Modifier.width(8.dp))
                            Text("فتح معادل صوت النظام الخارجي", color = themeStyle.accentPrimary)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showAudioSettingsSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = themeStyle.accentPrimary, contentColor = themeStyle.bgDark),
                        shape = themeStyle.buttonShape
                    ) {
                        Text("تم الحفظ", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}

@Composable
private fun OptionRowButton(
    style: ThemeStyleSpec,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(style.buttonShape)
            .clickable(onClick = onClick),
        color = style.bgDark
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = tint)
            Spacer(Modifier.width(12.dp))
            Text(title, color = style.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TopHeader(
    style: ThemeStyleSpec,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    sleepTimerLeft: Int?,
    onOpenThemes: () -> Unit,
    onOpenSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(style.bgTopGradient, style.bgDark)
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(style.buttonShape)
                        .background(Brush.linearGradient(listOf(style.accentPrimary, style.accentSecondary))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(style.icons.headerBadge, contentDescription = null, tint = style.bgDark)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MusicWave Pro",
                        color = style.textPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = if (sleepTimerLeft != null) "مؤقت النوم: متبقي $sleepTimerLeft دقيقة" else style.type.titleAr,
                        color = style.accentPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Row {
                IconButton(onClick = onOpenThemes) {
                    Icon(Icons.Default.Palette, contentDescription = "الثيمات والمؤثرات", tint = style.accentSecondary)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(style.icons.equalizer, contentDescription = "إعدادات الصوت", tint = style.accentPrimary)
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "تحديث المكتبة", tint = style.textPrimary)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث عن أغنية، فنان، أو ألبوم...", color = style.textSecondary) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = style.accentPrimary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "مسح", tint = style.textSecondary)
                    }
                }
            },
            singleLine = true,
            shape = style.buttonShape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = style.cardColor,
                unfocusedContainerColor = style.cardColor,
                focusedBorderColor = style.accentPrimary,
                unfocusedBorderColor = style.textSecondary.copy(alpha = 0.2f),
                focusedTextColor = style.textPrimary,
                unfocusedTextColor = style.textPrimary
            )
        )
    }
}

@Composable
private fun PermissionPromptCard(
    style: ThemeStyleSpec,
    onRequestPermission: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = style.cardColor),
            shape = style.cardShape
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    style.icons.tabSongs,
                    contentDescription = null,
                    tint = style.accentPrimary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "السماح بالوصول إلى ملفات الصوت",
                    color = style.textPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "يحتاج تطبيق MusicWave Pro إلى إذن قراءة الملفات الصوتية لعرض وتشغيل جميع الأغاني والمهرجانات المحفوظة على هاتفك.",
                    color = style.textSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = style.accentPrimary, contentColor = style.bgDark),
                    shape = style.buttonShape,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("منح الإذن واستعراض الأغاني", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun AllSongsTab(
    style: ThemeStyleSpec,
    songs: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    sortOption: SortOption,
    onSortChange: (SortOption) -> Unit,
    onSongClick: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onMoreOptions: (Song) -> Unit,
    onShuffleAll: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = onShuffleAll,
                colors = ButtonDefaults.buttonColors(containerColor = style.accentSecondary, contentColor = Color.White),
                shape = style.buttonShape
            ) {
                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("عشوائي (${songs.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(SortOption.values()) { option ->
                    FilterChip(
                        selected = sortOption == option,
                        onClick = { onSortChange(option) },
                        label = { Text(option.labelAr, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = style.accentPrimary.copy(alpha = 0.22f),
                            selectedLabelColor = style.accentPrimary,
                            labelColor = style.textSecondary
                        )
                    )
                }
            }
        }

        if (songs.isEmpty()) {
            EmptyStateBox(style, "لم يتم العثور على مقاطع صوتية على الجهاز")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    SongRowItem(
                        style = style,
                        song = song,
                        isSelected = currentSong?.id == song.id,
                        isPlaying = isPlaying && currentSong?.id == song.id,
                        isFavorite = favorites.contains(song.id),
                        onClick = { onSongClick(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onActionClick = { onMoreOptions(song) },
                        customActionIcon = Icons.Default.MoreVert
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(
    style: ThemeStyleSpec,
    playlists: List<Playlist>,
    allSongs: List<Song>,
    activePlaylist: Playlist?,
    currentSong: Song?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    onSelectPlaylist: (Playlist) -> Unit,
    onBackToPlaylists: () -> Unit,
    onCreateNew: () -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlaySong: (Song, List<Song>) -> Unit,
    onMoveSongInPlaylist: (String, Int, Int) -> Unit,
    onRemoveSongFromPlaylist: (String, Long) -> Unit,
    onToggleFavorite: (Song) -> Unit
) {
    if (activePlaylist != null) {
        // Map songIds in exact stored order so drag-and-drop reordering is reflected immediately!
        val songById = remember(allSongs) { allSongs.associateBy { it.id } }
        val playlistSongs = remember(activePlaylist.songIds, songById) {
            activePlaylist.songIds.mapNotNull { id -> songById[id] }
        }

        var draggedIndex by remember { mutableStateOf<Int?>(null) }
        var dragOffsetY by remember { mutableFloatStateOf(0f) }
        val itemHeightPx = with(LocalDensity.current) { 74.dp.toPx() }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBackToPlaylists) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = style.accentPrimary)
                    }
                    Column {
                        Text(activePlaylist.name, color = style.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${playlistSongs.size} أغنية • اسحب من (≡) لترتيب الأغاني وحفظها",
                            color = style.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                if (playlistSongs.isNotEmpty()) {
                    Button(
                        onClick = { onPlaySong(playlistSongs.first(), playlistSongs) },
                        colors = ButtonDefaults.buttonColors(containerColor = style.accentPrimary, contentColor = style.bgDark),
                        shape = style.buttonShape
                    ) {
                        Icon(style.icons.playFilled, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("تشغيل", fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (playlistSongs.isEmpty()) {
                EmptyStateBox(style, "هذه القائمة فارغة. أضف أغاني من تبويب الأغاني باستخدام زر الخيارات (⋮)")
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 20.dp)
                ) {
                    itemsIndexed(playlistSongs, key = { _, s -> s.id }) { index, song ->
                        val isDraggingThis = draggedIndex == index
                        val isSelected = currentSong?.id == song.id

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .zIndex(if (isDraggingThis) 3f else 0f)
                                .graphicsLayer {
                                    translationY = if (isDraggingThis) dragOffsetY else 0f
                                    scaleX = if (isDraggingThis) 1.03f else 1f
                                    scaleY = if (isDraggingThis) 1.03f else 1f
                                    shadowElevation = if (isDraggingThis) 18f else 0f
                                }
                                .clip(style.cardShape)
                                .border(
                                    width = if (isDraggingThis) 2.dp else if (isSelected) style.cardBorderWidth else 0.dp,
                                    color = if (isDraggingThis) style.accentPrimary else if (isSelected) style.accentPrimary.copy(alpha = 0.6f) else Color.Transparent,
                                    shape = style.cardShape
                                )
                                .clickable { onPlaySong(song, playlistSongs) },
                            color = if (isDraggingThis) style.cardColor else if (isSelected) style.cardColor.copy(alpha = 0.95f) else style.cardColor.copy(alpha = 0.45f),
                            shape = style.cardShape
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Dedicated Touch Drag Handle for instant smooth drag-and-drop
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isDraggingThis) style.accentPrimary.copy(alpha = 0.25f)
                                            else Color.Transparent
                                        )
                                        .pointerInput(playlistSongs.size) {
                                            detectDragGestures(
                                                onDragStart = {
                                                    draggedIndex = index
                                                    dragOffsetY = 0f
                                                },
                                                onDragEnd = {
                                                    draggedIndex = null
                                                    dragOffsetY = 0f
                                                },
                                                onDragCancel = {
                                                    draggedIndex = null
                                                    dragOffsetY = 0f
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragOffsetY += dragAmount.y
                                                    val currentIdx = draggedIndex ?: return@detectDragGestures
                                                    if (dragOffsetY > itemHeightPx && currentIdx < playlistSongs.lastIndex) {
                                                        onMoveSongInPlaylist(activePlaylist.id, currentIdx, currentIdx + 1)
                                                        draggedIndex = currentIdx + 1
                                                        dragOffsetY -= itemHeightPx
                                                    } else if (dragOffsetY < -itemHeightPx && currentIdx > 0) {
                                                        onMoveSongInPlaylist(activePlaylist.id, currentIdx, currentIdx - 1)
                                                        draggedIndex = currentIdx - 1
                                                        dragOffsetY += itemHeightPx
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.DragHandle,
                                        contentDescription = "اسحب لنقل الأغنية",
                                        tint = if (isDraggingThis) style.accentPrimary else style.textSecondary
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(if (style.isCircularArtwork) CircleShape else style.buttonShape)
                                        .background(style.bgDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = song.albumArtUri,
                                        contentDescription = song.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }

                                Spacer(Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${index + 1}. ${song.title}",
                                        color = if (isSelected) style.accentPrimary else style.textPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${song.artist} • ${formatDuration(song.duration)}",
                                        color = style.textSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                IconButton(
                                    onClick = { onToggleFavorite(song) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = if (favorites.contains(song.id)) style.icons.favActive else style.icons.favInactive,
                                        contentDescription = "مفضلة",
                                        tint = if (favorites.contains(song.id)) style.accentSecondary else style.textSecondary
                                    )
                                }

                                IconButton(
                                    onClick = { onRemoveSongFromPlaylist(activePlaylist.id, song.id) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RemoveCircleOutline,
                                        contentDescription = "إزالة من القائمة",
                                        tint = style.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("قوائم التشغيل الخاصة بك", color = style.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = onCreateNew,
                    colors = ButtonDefaults.buttonColors(containerColor = style.accentPrimary, contentColor = style.bgDark),
                    shape = style.buttonShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("قائمة جديدة", fontWeight = FontWeight.Bold)
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(playlists, key = { it.id }) { pl ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = style.cardBorderWidth,
                                color = style.accentPrimary.copy(alpha = 0.25f),
                                shape = style.cardShape
                            )
                            .clickable { onSelectPlaylist(pl) },
                        colors = CardDefaults.cardColors(containerColor = style.cardColor),
                        shape = style.cardShape
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(style.buttonShape)
                                        .background(Brush.linearGradient(listOf(style.accentSecondary, style.accentPrimary))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(style.icons.tabPlaylists, contentDescription = null, tint = style.bgDark)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(pl.name, color = style.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("${pl.songIds.size} مقطع صوتي • يدعم السحب والترتيب", color = style.textSecondary, fontSize = 12.sp)
                                }
                            }
                            IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = style.textSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoritesTab(
    style: ThemeStyleSpec,
    allSongs: List<Song>,
    favorites: Set<Long>,
    currentSong: Song?,
    isPlaying: Boolean,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onMoreOptions: (Song) -> Unit
) {
    val favSongs = remember(allSongs, favorites) {
        allSongs.filter { favorites.contains(it.id) }
    }
    if (favSongs.isEmpty()) {
        EmptyStateBox(style, "لم تقم بإضافة أغاني إلى المفضلة بعد")
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(favSongs, key = { it.id }) { song ->
                SongRowItem(
                    style = style,
                    song = song,
                    isSelected = currentSong?.id == song.id,
                    isPlaying = isPlaying && currentSong?.id == song.id,
                    isFavorite = true,
                    onClick = { onPlaySong(song, favSongs) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    onActionClick = { onMoreOptions(song) },
                    customActionIcon = Icons.Default.MoreVert
                )
            }
        }
    }
}

@Composable
private fun FoldersTab(
    style: ThemeStyleSpec,
    allSongs: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onMoreOptions: (Song) -> Unit
) {
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    val grouped = remember(allSongs) { allSongs.groupBy { it.folderName } }

    if (selectedFolder != null) {
        val folderSongs = grouped[selectedFolder].orEmpty()
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selectedFolder = null }) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = style.accentPrimary)
                }
                Text(
                    text = "مجلد: $selectedFolder (${folderSongs.size})",
                    color = style.textPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(folderSongs, key = { it.id }) { song ->
                    SongRowItem(
                        style = style,
                        song = song,
                        isSelected = currentSong?.id == song.id,
                        isPlaying = isPlaying && currentSong?.id == song.id,
                        isFavorite = favorites.contains(song.id),
                        onClick = { onPlaySong(song, folderSongs) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onActionClick = { onMoreOptions(song) },
                        customActionIcon = Icons.Default.MoreVert
                    )
                }
            }
        }
    } else {
        if (grouped.isEmpty()) {
            EmptyStateBox(style, "لا توجد مجلدات موسيقية")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(grouped.entries.toList(), key = { it.key }) { (folderName, list) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = style.cardBorderWidth,
                                color = style.accentPrimary.copy(alpha = 0.2f),
                                shape = style.cardShape
                            )
                            .clickable { selectedFolder = folderName },
                        colors = CardDefaults.cardColors(containerColor = style.cardColor),
                        shape = style.cardShape
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(style.icons.tabFolders, contentDescription = null, tint = style.accentPrimary, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(folderName, color = style.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("${list.size} أغنية", color = style.textSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SongRowItem(
    style: ThemeStyleSpec,
    song: Song,
    isSelected: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onActionClick: () -> Unit,
    customActionIcon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.MoreVert
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(style.cardShape)
            .border(
                width = if (isSelected) style.cardBorderWidth else 0.5.dp,
                color = if (isSelected) style.accentPrimary else style.cardColor,
                shape = style.cardShape
            )
            .clickable(onClick = onClick),
        color = if (isSelected) style.cardColor else style.cardColor.copy(alpha = 0.38f),
        shape = style.cardShape
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(if (style.isCircularArtwork) CircleShape else style.buttonShape)
                    .background(style.bgDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    style.icons.artworkCenter,
                    contentDescription = null,
                    tint = style.accentPrimary.copy(alpha = 0.35f),
                    modifier = Modifier.size(24.dp)
                )
                AsyncImage(
                    model = song.albumArtUri,
                    contentDescription = song.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isPlaying) style.icons.equalizer else style.icons.playFilled,
                            contentDescription = null,
                            tint = style.accentPrimary
                        )
                    }
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = if (isSelected) style.accentPrimary else style.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${song.artist} • ${formatDuration(song.duration)}",
                    color = style.textSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (isFavorite) style.icons.favActive else style.icons.favInactive,
                    contentDescription = "مفضلة",
                    tint = if (isFavorite) style.accentSecondary else style.textSecondary
                )
            }

            IconButton(onClick = onActionClick) {
                Icon(
                    imageVector = customActionIcon,
                    contentDescription = "خيارات",
                    tint = style.textSecondary
                )
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(
    style: ThemeStyleSpec,
    song: Song,
    isPlaying: Boolean,
    progress: Float,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onOpenQueue: () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(style.miniPlayerShape)
            .border(
                width = style.cardBorderWidth,
                color = style.accentPrimary.copy(alpha = 0.45f),
                shape = style.miniPlayerShape
            )
            .clickable(onClick = onClick),
        color = style.cardColor,
        tonalElevation = 10.dp,
        shape = style.miniPlayerShape
    ) {
        Column {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = style.accentPrimary,
                trackColor = Color.Transparent
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(if (style.isCircularArtwork) CircleShape else style.buttonShape)
                        .background(Brush.linearGradient(listOf(style.accentPrimary, style.accentSecondary))),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = song.albumArtUri,
                        contentDescription = song.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = style.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        song.artist,
                        color = style.accentPrimary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onOpenQueue) {
                    Icon(style.icons.tabPlaylists, contentDescription = "طابور التشغيل", tint = style.textSecondary)
                }
                IconButton(onClick = onTogglePlay) {
                    Icon(
                        if (isPlaying) style.icons.pauseFilled else style.icons.playFilled,
                        contentDescription = "تشغيل/إيقاف",
                        tint = style.accentPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "التالي", tint = style.textPrimary)
                }
            }
        }
    }
}

@Composable
private fun NowPlayingFullScreen(
    style: ThemeStyleSpec,
    song: Song,
    isPlaying: Boolean,
    currentPosition: Long,
    duration: Long,
    shuffleEnabled: Boolean,
    repeatState: RepeatState,
    isFavorite: Boolean,
    playbackSpeed: Float,
    visualizerMode: VisualizerMode,
    visualizerBars: List<Float>,
    hasLyrics: Boolean,
    onClose: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCycleVisualizer: () -> Unit,
    onOpenThemes: () -> Unit,
    onOpenOptions: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenLyrics: () -> Unit,
    onOpenAudioSettings: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = style.bgDark
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(style.bgTopGradient, style.bgDark, Color.Black)
                    )
                )
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "إغلاق", tint = style.textPrimary, modifier = Modifier.size(32.dp))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(style.type.titleAr, color = style.accentPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(song.folderName, color = style.textSecondary, fontSize = 11.sp)
                }
                Row {
                    IconButton(onClick = onOpenThemes) {
                        Icon(Icons.Default.Palette, contentDescription = "الثيمات والمؤثرات", tint = style.accentSecondary)
                    }
                    IconButton(onClick = onOpenAudioSettings) {
                        Icon(style.icons.equalizer, contentDescription = "المؤثرات", tint = style.accentPrimary)
                    }
                    IconButton(onClick = onOpenOptions) {
                        Icon(Icons.Default.MoreVert, contentDescription = "خيارات الأغنية", tint = style.textPrimary)
                    }
                }
            }

            // Artwork Card + Multi-Mode Hyper-Realistic Visualizer
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(215.dp)
                        .clip(style.artworkShape)
                        .border(
                            width = 2.dp,
                            brush = Brush.linearGradient(listOf(style.accentPrimary, style.accentSecondary)),
                            shape = style.artworkShape
                        )
                        .background(Brush.linearGradient(listOf(style.cardColor, style.bgTopGradient))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        style.icons.artworkCenter,
                        contentDescription = null,
                        tint = style.accentPrimary.copy(alpha = 0.4f),
                        modifier = Modifier.size(88.dp)
                    )
                    AsyncImage(
                        model = song.albumArtUri,
                        contentDescription = song.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(Modifier.height(12.dp))

                // Interactive Visualizer Box (Tap to cycle through 6 realistic visualizers!)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(style.cardShape)
                        .border(
                            width = 1.dp,
                            color = style.accentPrimary.copy(alpha = 0.25f),
                            shape = style.cardShape
                        )
                        .clickable { onCycleVisualizer() },
                    color = style.cardColor.copy(alpha = 0.55f),
                    shape = style.cardShape
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = visualizerMode.titleAr,
                                color = style.accentPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "اضغط لتغيير المؤثر ↻",
                                color = style.textSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        HyperRealisticVisualizer(
                            mode = visualizerMode,
                            isPlaying = isPlaying,
                            realBars = visualizerBars,
                            primaryColor = style.accentPrimary,
                            secondaryColor = style.accentSecondary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(82.dp)
                        )
                    }
                }
            }

            // Song Info + Lyrics / Queue / Theme actions
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = style.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${song.artist} • ${song.album}",
                            color = style.textSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (isFavorite) style.icons.favActive else style.icons.favInactive,
                            contentDescription = "مفضلة",
                            tint = if (isFavorite) style.accentSecondary else style.textPrimary
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                // Action Pills
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        AssistChip(
                            onClick = onOpenThemes,
                            label = { Text("الثيم والمؤثرات", fontSize = 12.sp, color = style.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null, tint = style.accentPrimary, modifier = Modifier.size(16.dp)) },
                            border = BorderStroke(1.dp, style.accentPrimary.copy(alpha = 0.4f))
                        )
                    }
                    item {
                        AssistChip(
                            onClick = onOpenLyrics,
                            label = { Text(if (hasLyrics) "الكلمات ✓" else "الكلمات", fontSize = 12.sp, color = style.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Lyrics, contentDescription = null, tint = style.accentPrimary, modifier = Modifier.size(16.dp)) },
                            border = BorderStroke(1.dp, style.accentPrimary.copy(alpha = 0.4f))
                        )
                    }
                    item {
                        AssistChip(
                            onClick = onOpenQueue,
                            label = { Text("طابور التشغيل", fontSize = 12.sp, color = style.textPrimary) },
                            leadingIcon = { Icon(style.icons.tabPlaylists, contentDescription = null, tint = style.accentSecondary, modifier = Modifier.size(16.dp)) },
                            border = BorderStroke(1.dp, style.accentSecondary.copy(alpha = 0.4f))
                        )
                    }
                    item {
                        AssistChip(
                            onClick = onOpenOptions,
                            label = { Text("مشاركة / نغمة", fontSize = 12.sp, color = style.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = style.textPrimary, modifier = Modifier.size(16.dp)) },
                            border = BorderStroke(1.dp, style.textSecondary.copy(alpha = 0.4f))
                        )
                    }
                }
            }

            // SeekBar & Controls
            Column(modifier = Modifier.fillMaxWidth()) {
                val safeDuration = duration.coerceAtLeast(1L)
                Slider(
                    value = currentPosition.coerceIn(0L, safeDuration).toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..safeDuration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = style.accentPrimary,
                        activeTrackColor = style.accentPrimary,
                        inactiveTrackColor = style.cardColor
                    )
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatDuration(currentPosition), color = style.textSecondary, fontSize = 12.sp)
                    Text("${playbackSpeed}x", color = style.accentSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(formatDuration(duration), color = style.textSecondary, fontSize = 12.sp)
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onToggleShuffle) {
                        Icon(
                            Icons.Default.Shuffle,
                            contentDescription = "عشوائي",
                            tint = if (shuffleEnabled) style.accentPrimary else style.textSecondary
                        )
                    }

                    IconButton(onClick = onPrevious, modifier = Modifier.size(50.dp)) {
                        Icon(Icons.Default.SkipNext, contentDescription = "السابق", tint = style.textPrimary, modifier = Modifier.size(34.dp))
                    }

                    FloatingActionButton(
                        onClick = onTogglePlay,
                        containerColor = style.accentPrimary,
                        contentColor = style.bgDark,
                        shape = style.buttonShape,
                        modifier = Modifier.size(68.dp)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "تشغيل",
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(onClick = onNext, modifier = Modifier.size(50.dp)) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "التالي", tint = style.textPrimary, modifier = Modifier.size(34.dp))
                    }

                    IconButton(onClick = onCycleRepeat) {
                        val icon = when (repeatState) {
                            RepeatState.ONE -> Icons.Default.RepeatOne
                            else -> Icons.Default.Repeat
                        }
                        val tint = if (repeatState == RepeatState.OFF) style.textSecondary else style.accentPrimary
                        Icon(icon, contentDescription = "تكرار", tint = tint)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStateBox(style: ThemeStyleSpec, message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.MusicOff, contentDescription = null, tint = style.textSecondary, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(12.dp))
            Text(message, color = style.textSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
