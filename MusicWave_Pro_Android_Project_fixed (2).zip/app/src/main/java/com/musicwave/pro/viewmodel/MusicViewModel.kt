package com.musicwave.pro.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.musicwave.pro.data.MusicRepository
import com.musicwave.pro.model.AppThemeType
import com.musicwave.pro.model.EqPreset
import com.musicwave.pro.model.LrcLine
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.RepeatState
import com.musicwave.pro.model.Song
import com.musicwave.pro.model.SortOption
import com.musicwave.pro.model.VisualizerMode
import com.musicwave.pro.service.AudioSessionBridge
import com.musicwave.pro.service.MusicPlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.hypot

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MusicRepository(application)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null
    private var visualizer: Visualizer? = null

    private val persisted = repository.loadPersistedSettings()
    private var pendingRestoreSongId: Long = persisted.lastSongId
    private var pendingRestorePositionMs: Long = persisted.lastPositionMs

    private val _allSongs = MutableStateFlow<List<Song>>(emptyList())
    val allSongs: StateFlow<List<Song>> = _allSongs.asStateFlow()

    private val _currentQueue = MutableStateFlow<List<Song>>(emptyList())
    val currentQueue: StateFlow<List<Song>> = _currentQueue.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(persisted.lastPositionMs)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(persisted.shuffleEnabled)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _repeatState = MutableStateFlow(
        runCatching { RepeatState.valueOf(persisted.repeatStateName) }.getOrDefault(RepeatState.OFF)
    )
    val repeatState: StateFlow<RepeatState> = _repeatState.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(persisted.playbackSpeed)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _bassStrength = MutableStateFlow(persisted.bassStrength)
    val bassStrength: StateFlow<Int> = _bassStrength.asStateFlow()

    private val _eqBands = MutableStateFlow(persisted.eqBands)
    val eqBands: StateFlow<List<Int>> = _eqBands.asStateFlow()

    private val _activePresetId = MutableStateFlow(persisted.activePresetId)
    val activePresetId: StateFlow<String> = _activePresetId.asStateFlow()

    private val _selectedTheme = MutableStateFlow(
        AppThemeType.values().find { it.id == persisted.themeId } ?: AppThemeType.NEON_CYBER
    )
    val selectedTheme: StateFlow<AppThemeType> = _selectedTheme.asStateFlow()

    private val _visualizerMode = MutableStateFlow(
        VisualizerMode.values().find { it.id == persisted.visualizerId } ?: VisualizerMode.SPECTRUM_PEAKS
    )
    val visualizerMode: StateFlow<VisualizerMode> = _visualizerMode.asStateFlow()

    // 32-band real-time FFT spectrum normalized 0f..1f
    private val _visualizerBars = MutableStateFlow<List<Float>>(emptyList())
    val visualizerBars: StateFlow<List<Float>> = _visualizerBars.asStateFlow()

    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOption = MutableStateFlow(
        runCatching { SortOption.valueOf(persisted.sortOptionName) }.getOrDefault(SortOption.DATE_ADDED)
    )
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _sleepTimerMinutesLeft = MutableStateFlow<Int?>(null)
    val sleepTimerMinutesLeft: StateFlow<Int?> = _sleepTimerMinutesLeft.asStateFlow()

    private val _currentLyrics = MutableStateFlow("")
    val currentLyrics: StateFlow<String> = _currentLyrics.asStateFlow()

    val syncedLyrics: StateFlow<List<LrcLine>> = combine(_currentSong, _currentLyrics) { song, _ -> song }
        .map { song -> if (song == null) emptyList<LrcLine>() else repository.getSyncedLyricsForSong(song) }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<LrcLine>())

    private val _ambientFx = MutableStateFlow(persisted.ambientFxEnabled)
    val ambientFxEnabled: StateFlow<Boolean> = _ambientFx.asStateFlow()

    private var agcPeak = 60f

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private var sleepTimerJob: Job? = null

    val eqPresets = listOf(
        EqPreset("flat", "عادي (Flat)", listOf(0, 0, 0, 0, 0)),
        EqPreset("shaabi", "مهرجانات وشعبي", listOf(1150, 750, -50, 650, 1000)),
        EqPreset("bass", "بيز عميق (Sub-Bass)", listOf(1400, 950, 0, -200, 300)),
        EqPreset("mawwal", "موال وصوت نقي", listOf(-150, 400, 1050, 850, 350)),
        EqPreset("rock", "حماس واستوديو", listOf(900, 450, -250, 600, 1100))
    )

    init {
        _favorites.value = repository.getFavoriteIds()
        _playlists.value = repository.getPlaylists()
        initializeController()
        observeAudioSessionId()
        startProgressUpdater()
    }

    fun setTheme(theme: AppThemeType) {
        _selectedTheme.value = theme
        repository.saveSetting("theme_id", theme.id)
    }

    fun setAmbientFx(enabled: Boolean) {
        _ambientFx.value = enabled
        repository.saveSetting("ambient_fx", enabled.toString())
    }

    fun setVisualizerMode(mode: VisualizerMode) {
        _visualizerMode.value = mode
        repository.saveSetting("visualizer_id", mode.id)
    }

    private fun observeAudioSessionId() {
        viewModelScope.launch {
            AudioSessionBridge.audioSessionId.collect { sessionId ->
                if (sessionId > 0) {
                    attachAudioEffectsToSession(sessionId)
                    attachRealVisualizer(sessionId)
                }
            }
        }
    }

    private fun attachAudioEffectsToSession(sessionId: Int) {
        try {
            bassBoost?.release()
            bassBoost = BassBoost(0, sessionId).apply {
                enabled = true
                setStrength(_bassStrength.value.toShort())
            }
        } catch (_: Exception) {
        }

        try {
            equalizer?.release()
            equalizer = Equalizer(0, sessionId).apply {
                enabled = true
                val numBands = numberOfBands.toInt().coerceAtMost(5)
                val range = bandLevelRange
                for (i in 0 until numBands) {
                    val target = _eqBands.value.getOrElse(i) { 0 }
                        .coerceIn(range[0].toInt(), range[1].toInt())
                    setBandLevel(i.toShort(), target.toShort())
                }
            }
        } catch (_: Exception) {
        }
    }

    fun attachRealVisualizer(sessionId: Int = AudioSessionBridge.audioSessionId.value) {
        if (sessionId <= 0) return
        try {
            visualizer?.release()
            val captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
            visualizer = Visualizer(sessionId).apply {
                enabled = false
                setCaptureSize(captureSize)
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(
                            v: Visualizer?,
                            waveform: ByteArray?,
                            samplingRate: Int
                        ) {
                        }

                        override fun onFftDataCapture(
                            v: Visualizer?,
                            fft: ByteArray?,
                            samplingRate: Int
                        ) {
                            if (fft == null || !_isPlaying.value) return
                            val barCount = 32
                            val magnitudes = FloatArray(barCount)
                            val maxBin = (fft.size / 2 - 1).coerceAtLeast(barCount + 1)
                            val prev = _visualizerBars.value
                            val raw = FloatArray(barCount)
                            var framePeak = 0f
                            // Logarithmic band mapping: bass gets more bars, like human hearing
                            for (i in 0 until barCount) {
                                val lo = Math.pow(maxBin.toDouble(), i / barCount.toDouble()).toInt().coerceIn(1, maxBin)
                                val hi = Math.pow(maxBin.toDouble(), (i + 1) / barCount.toDouble()).toInt().coerceIn(lo + 1, maxBin + 1)
                                var sum = 0f
                                var cnt = 0
                                var k = lo
                                while (k < hi && (2 * k + 1) < fft.size) {
                                    sum += hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat())
                                    cnt++
                                    k++
                                }
                                val mag = if (cnt > 0) sum / cnt else 0f
                                raw[i] = mag
                                if (mag > framePeak) framePeak = mag
                            }
                            // Auto gain: adapts to quiet and loud songs
                            agcPeak = maxOf(framePeak, agcPeak * 0.995f, 24f)
                            for (i in 0 until barCount) {
                                val tilt = 1f + 0.9f * (i / (barCount - 1f))
                                val normalized = Math.pow(
                                    ((raw[i] * tilt) / agcPeak).coerceIn(0f, 1f).toDouble(),
                                    0.7
                                ).toFloat().coerceIn(0.08f, 1f)
                                val prevVal = prev.getOrElse(i) { 0.1f }
                                // Fast attack, smooth decay
                                magnitudes[i] = if (normalized > prevVal) {
                                    prevVal * 0.3f + normalized * 0.7f
                                } else {
                                    (prevVal * 0.72f + normalized * 0.28f).coerceAtLeast(0.08f)
                                }
                            }
                            _visualizerBars.value = magnitudes.toList()
                        }
                    },
                    Visualizer.getMaxCaptureRate() / 2,
                    false,
                    true
                )
                enabled = true
            }
        } catch (_: Exception) {
            _visualizerBars.value = emptyList()
        }
    }

    private fun initializeController() {
        val context = getApplication<Application>()
        val sessionToken = SessionToken(context, ComponentName(context, MusicPlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
            applySavedPlayerParamsToController()
            setupPlayerListener()
            tryRestoreLastSession()
        }, MoreExecutors.directExecutor())
    }

    private fun applySavedPlayerParamsToController() {
        val controller = mediaController ?: return
        controller.shuffleModeEnabled = _shuffleEnabled.value
        controller.repeatMode = when (_repeatState.value) {
            RepeatState.OFF -> Player.REPEAT_MODE_OFF
            RepeatState.ALL -> Player.REPEAT_MODE_ALL
            RepeatState.ONE -> Player.REPEAT_MODE_ONE
        }
        controller.playbackParameters = PlaybackParameters(_playbackSpeed.value)
    }

    private fun setupPlayerListener() {
        mediaController?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (!isPlaying) {
                    saveCurrentPlaybackState()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val songId = mediaItem?.mediaId?.toLongOrNull()
                if (songId != null) {
                    val found = _allSongs.value.find { it.id == songId }
                    _currentSong.value = found
                    repository.saveSetting("last_song_id", songId.toString())
                    if (found != null) {
                        _currentLyrics.value = repository.getLyricsForSong(found)
                    }
                }
                _duration.value = (mediaController?.duration ?: 0L).coerceAtLeast(0L)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = (mediaController?.duration ?: 0L).coerceAtLeast(0L)
                }
            }
        })
    }

    private fun startProgressUpdater() {
        viewModelScope.launch {
            var tick = 0
            while (true) {
                if (_isPlaying.value) {
                    val pos = (mediaController?.currentPosition ?: 0L).coerceAtLeast(0L)
                    _currentPosition.value = pos
                    val d = mediaController?.duration ?: 0L
                    if (d > 0) _duration.value = d
                    tick++
                    if (tick % 6 == 0) {
                        repository.saveSetting("last_position_ms", pos.toString())
                    }
                }
                delay(500L)
            }
        }
    }

    private fun saveCurrentPlaybackState() {
        _currentSong.value?.let { song ->
            repository.saveSetting("last_song_id", song.id.toString())
        }
        val pos = (mediaController?.currentPosition ?: _currentPosition.value).coerceAtLeast(0L)
        repository.saveSetting("last_position_ms", pos.toString())
    }

    fun loadSongs() {
        viewModelScope.launch {
            _isLoading.value = true
            val scanned = repository.scanDeviceSongs()
            _allSongs.value = sortSongsList(scanned, _sortOption.value)
            if (_currentQueue.value.isEmpty()) {
                _currentQueue.value = _allSongs.value
            }
            _isLoading.value = false
            tryRestoreLastSession()
        }
    }

    private fun tryRestoreLastSession() {
        val controller = mediaController ?: return
        val songs = _allSongs.value
        if (songs.isEmpty()) return

        // If player is already active with a song, sync state from controller
        val activeMediaId = controller.currentMediaItem?.mediaId?.toLongOrNull()
        if (activeMediaId != null) {
            val found = songs.find { it.id == activeMediaId }
            if (found != null) {
                _currentSong.value = found
                _currentLyrics.value = repository.getLyricsForSong(found)
                _isPlaying.value = controller.isPlaying
                _duration.value = controller.duration.coerceAtLeast(found.duration)
                return
            }
        }

        // Otherwise restore last saved song without auto-playing so user never loses where they left off
        if (_currentSong.value == null && pendingRestoreSongId != -1L) {
            val savedSong = songs.find { it.id == pendingRestoreSongId }
            if (savedSong != null) {
                _currentSong.value = savedSong
                _currentLyrics.value = repository.getLyricsForSong(savedSong)
                _duration.value = savedSong.duration
                val mediaItems = songs.map { item ->
                    val metadata = MediaMetadata.Builder()
                        .setTitle(item.title)
                        .setArtist(item.artist)
                        .setAlbumTitle(item.album)
                        .setArtworkUri(item.albumArtUri)
                        .build()
                    MediaItem.Builder()
                        .setMediaId(item.id.toString())
                        .setUri(item.contentUri)
                        .setMediaMetadata(metadata)
                        .build()
                }
                val startIndex = songs.indexOfFirst { it.id == savedSong.id }.coerceAtLeast(0)
                controller.setMediaItems(mediaItems, startIndex, pendingRestorePositionMs.coerceAtLeast(0L))
                controller.prepare()
                pendingRestoreSongId = -1L
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSortOption(option: SortOption) {
        _sortOption.value = option
        _allSongs.value = sortSongsList(_allSongs.value, option)
        repository.saveSetting("sort_option", option.name)
    }

    private fun sortSongsList(list: List<Song>, option: SortOption): List<Song> {
        return when (option) {
            SortOption.TITLE -> list.sortedBy { it.title.lowercase() }
            SortOption.ARTIST -> list.sortedBy { it.artist.lowercase() }
            SortOption.DURATION -> list.sortedByDescending { it.duration }
            SortOption.DATE_ADDED -> list.sortedByDescending { it.dateAdded }
        }
    }

    fun playSongFromQueue(song: Song, customQueue: List<Song>? = null) {
        val queueToUse = customQueue ?: _allSongs.value
        _currentQueue.value = queueToUse
        _currentSong.value = song
        _currentLyrics.value = repository.getLyricsForSong(song)
        repository.saveSetting("last_song_id", song.id.toString())
        repository.saveSetting("last_position_ms", "0")

        val controller = mediaController ?: return
        val mediaItems = queueToUse.map { item ->
            val metadata = MediaMetadata.Builder()
                .setTitle(item.title)
                .setArtist(item.artist)
                .setAlbumTitle(item.album)
                .setArtworkUri(item.albumArtUri)
                .build()

            MediaItem.Builder()
                .setMediaId(item.id.toString())
                .setUri(item.contentUri)
                .setMediaMetadata(metadata)
                .build()
        }

        val startIndex = queueToUse.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        controller.setMediaItems(mediaItems, startIndex, 0L)
        controller.prepare()
        controller.play()
    }

    fun moveSongInQueue(fromIndex: Int, toIndex: Int) {
        val currentList = _currentQueue.value.toMutableList()
        if (fromIndex !in currentList.indices || toIndex !in currentList.indices || fromIndex == toIndex) return
        val moved = currentList.removeAt(fromIndex)
        currentList.add(toIndex, moved)
        _currentQueue.value = currentList
        mediaController?.moveMediaItem(fromIndex, toIndex)
    }

    fun removeSongFromQueue(index: Int) {
        val currentList = _currentQueue.value.toMutableList()
        if (index !in currentList.indices) return
        currentList.removeAt(index)
        _currentQueue.value = currentList
        mediaController?.removeMediaItem(index)
    }

    fun moveSongInPlaylist(playlistId: String, fromIndex: Int, toIndex: Int) {
        val pl = _playlists.value.find { it.id == playlistId } ?: return
        val currentIds = pl.songIds.toMutableList()
        if (fromIndex !in currentIds.indices || toIndex !in currentIds.indices || fromIndex == toIndex) return
        val movedId = currentIds.removeAt(fromIndex)
        currentIds.add(toIndex, movedId)

        // Update state immediately for zero-lag drag-and-drop UI
        _playlists.value = _playlists.value.map {
            if (it.id == playlistId) it.copy(songIds = currentIds) else it
        }
        // Persist new order in SQLite database
        repository.updatePlaylistSongOrder(playlistId, currentIds)
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.mediaItemCount == 0 && _allSongs.value.isNotEmpty()) {
            playSongFromQueue(_allSongs.value.first())
            return
        }
        if (controller.isPlaying) {
            controller.pause()
        } else {
            controller.play()
        }
    }

    fun playNext() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        } else if (_currentQueue.value.isNotEmpty()) {
            controller.seekTo(0, 0L)
            controller.play()
        }
    }

    fun playPrevious() {
        val controller = mediaController ?: return
        if (controller.currentPosition > 3000L) {
            controller.seekTo(0L)
        } else if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
        }
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
        _currentPosition.value = positionMs
        repository.saveSetting("last_position_ms", positionMs.toString())
    }

    fun toggleShuffle() {
        val next = !_shuffleEnabled.value
        _shuffleEnabled.value = next
        mediaController?.shuffleModeEnabled = next
        repository.saveSetting("shuffle_enabled", next.toString())
    }

    fun cycleRepeatMode() {
        val next = when (_repeatState.value) {
            RepeatState.OFF -> RepeatState.ALL
            RepeatState.ALL -> RepeatState.ONE
            RepeatState.ONE -> RepeatState.OFF
        }
        _repeatState.value = next
        mediaController?.repeatMode = when (next) {
            RepeatState.OFF -> Player.REPEAT_MODE_OFF
            RepeatState.ALL -> Player.REPEAT_MODE_ALL
            RepeatState.ONE -> Player.REPEAT_MODE_ONE
        }
        repository.saveSetting("repeat_state", next.name)
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        mediaController?.playbackParameters = PlaybackParameters(speed)
        repository.saveSetting("playback_speed", speed.toString())
    }

    fun setBassBoostStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        _bassStrength.value = clamped
        repository.saveSetting("bass_strength", clamped.toString())
        try {
            val sessionId = AudioSessionBridge.audioSessionId.value
            if (bassBoost == null && sessionId > 0) {
                bassBoost = BassBoost(0, sessionId).apply { enabled = true }
            }
            bassBoost?.setStrength(clamped.toShort())
        } catch (_: Exception) {
        }
    }

    fun setEqBandLevel(bandIndex: Int, levelMb: Int) {
        val clamped = levelMb.coerceIn(-1500, 1500)
        val updated = _eqBands.value.toMutableList()
        if (bandIndex in updated.indices) {
            updated[bandIndex] = clamped
            _eqBands.value = updated
        }
        _activePresetId.value = "custom"
        repository.saveSetting("active_preset_id", "custom")
        repository.saveSetting("eq_bands", updated.joinToString(","))
        applyEqToHardware(updated)
    }

    fun applyEqPreset(preset: EqPreset) {
        _activePresetId.value = preset.id
        _eqBands.value = preset.bandGainsMb
        repository.saveSetting("active_preset_id", preset.id)
        repository.saveSetting("eq_bands", preset.bandGainsMb.joinToString(","))
        applyEqToHardware(preset.bandGainsMb)
    }

    private fun applyEqToHardware(levels: List<Int>) {
        try {
            val sessionId = AudioSessionBridge.audioSessionId.value
            if (equalizer == null && sessionId > 0) {
                equalizer = Equalizer(0, sessionId).apply { enabled = true }
            }
            val eq = equalizer ?: return
            val range = eq.bandLevelRange
            val numBands = eq.numberOfBands.toInt().coerceAtMost(levels.size)
            for (i in 0 until numBands) {
                val lvl = levels[i].coerceIn(range[0].toInt(), range[1].toInt())
                eq.setBandLevel(i.toShort(), lvl.toShort())
            }
        } catch (_: Exception) {
        }
    }

    fun saveLyricsForCurrentSong(lyrics: String) {
        val song = _currentSong.value ?: return
        repository.saveLyricsForSong(song.id, lyrics)
        _currentLyrics.value = lyrics
    }

    fun shareSong(context: Context, song: Song) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, song.contentUri)
                putExtra(Intent.EXTRA_TITLE, song.title)
                putExtra(Intent.EXTRA_TEXT, "استمع إلى (${song.title} - ${song.artist}) عبر MusicWave Pro")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "مشاركة الأغنية عبر").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف الصوتي", Toast.LENGTH_SHORT).show()
        }
    }

    fun setSongAsRingtone(context: Context, song: Song) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(context)) {
                Toast.makeText(
                    context,
                    "يرجى منح إذن تعديل إعدادات النظام لتعيين نغمة الرنين",
                    Toast.LENGTH_LONG
                ).show()
                val settingsIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(settingsIntent)
                return
            }
            RingtoneManager.setActualDefaultRingtoneUri(
                context,
                RingtoneManager.TYPE_RINGTONE,
                song.contentUri
            )
            Toast.makeText(
                context,
                "تم تعيين (${song.title}) كنغمة رنين للهاتف بنجاح!",
                Toast.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر تعيين نغمة الرنين: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleFavorite(songId: Long) {
        val current = _favorites.value.toMutableSet()
        val nowFav = if (current.contains(songId)) {
            current.remove(songId)
            false
        } else {
            current.add(songId)
            true
        }
        _favorites.value = current
        repository.setFavorite(songId, nowFav)
    }

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        val newPlaylist = Playlist(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            songIds = emptyList()
        )
        repository.createPlaylist(newPlaylist)
        _playlists.value = repository.getPlaylists()
    }

    fun deletePlaylist(playlistId: String) {
        repository.deletePlaylist(playlistId)
        _playlists.value = repository.getPlaylists()
    }

    fun addSongToPlaylist(playlistId: String, songId: Long) {
        repository.addSongToPlaylist(playlistId, songId)
        _playlists.value = repository.getPlaylists()
    }

    fun removeSongFromPlaylist(playlistId: String, songId: Long) {
        repository.removeSongFromPlaylist(playlistId, songId)
        _playlists.value = repository.getPlaylists()
    }

    fun startSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null || minutes <= 0) {
            _sleepTimerMinutesLeft.value = null
            return
        }
        _sleepTimerMinutesLeft.value = minutes
        sleepTimerJob = viewModelScope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000L)
                remaining--
                _sleepTimerMinutesLeft.value = remaining
            }
            mediaController?.pause()
            _sleepTimerMinutesLeft.value = null
        }
    }

    override fun onCleared() {
        saveCurrentPlaybackState()
        super.onCleared()
        try {
            visualizer?.release()
            equalizer?.release()
            bassBoost?.release()
        } catch (_: Exception) {
        }
        controllerFuture?.let { MediaController.releaseFuture(it) }
    }
}
