package com.musicwave.pro.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

const val BAR_COUNT = 32

/**
 * Shared real-time audio state used by every visual effect.
 * One driver is created for the whole app and updated once per frame.
 */
@Stable
class AudioDriver {
    var time by mutableFloatStateOf(0f)
    var travel by mutableFloatStateOf(0f)
    var beat by mutableFloatStateOf(0f)
    var bass by mutableFloatStateOf(0f)
    var mid by mutableFloatStateOf(0f)
    var treble by mutableFloatStateOf(0f)
    val levels = FloatArray(BAR_COUNT) { 0.1f }
}

fun fract01(x: Float): Float = x - floor(x)

fun mixColor(a: Color, b: Color, t: Float): Color {
    val f = t.coerceIn(0f, 1f)
    return Color(
        a.red + (b.red - a.red) * f,
        a.green + (b.green - a.green) * f,
        a.blue + (b.blue - a.blue) * f,
        a.alpha + (b.alpha - a.alpha) * f
    )
}

@Composable
fun rememberAudioDriver(isPlaying: Boolean, realBars: List<Float>): AudioDriver {
    val driver = remember { AudioDriver() }
    val playingState = rememberUpdatedState(isPlaying)
    val barsState = rememberUpdatedState(realBars)

    LaunchedEffect(driver) {
        var lastNanos = 0L
        var slowBass = 0.2f
        while (true) {
            val playing = playingState.value
            val settled = !playing && driver.bass < 0.14f && driver.beat < 0.01f
            if (settled) {
                lastNanos = 0L
                delay(120)
                continue
            }
            withFrameNanos { now ->
                val dt = if (lastNanos == 0L) 0.016f
                else ((now - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                lastNanos = now

                val t = driver.time + dt
                driver.time = t
                val bars = barsState.value
                val lv = driver.levels
                for (i in 0 until BAR_COUNT) {
                    val target = if (!playing) {
                        0.10f + 0.03f * sin(i * 0.4f)
                    } else if (bars.size >= BAR_COUNT) {
                        bars[i].coerceIn(0.08f, 1f)
                    } else {
                        val ph = t * 8.7266f
                        val subBass = if (i < 6) 0.32f * abs(sin(ph * 2f)) else 0f
                        val midPunch = 0.42f * abs(sin(ph * 1.5f + i * 0.38f))
                        val highSparkle = 0.24f * abs(cos(ph * 3f - i * 0.65f))
                        (0.12f + subBass + midPunch + highSparkle).coerceIn(0.12f, 0.98f)
                    }
                    val cur = lv[i]
                    lv[i] = if (target > cur) cur + (target - cur) * 0.6f else cur + (target - cur) * 0.18f
                }

                var b = 0f
                for (i in 0..3) b += lv[i]
                b /= 4f
                var m = 0f
                for (i in 4..15) m += lv[i]
                m /= 12f
                var tr = 0f
                for (i in 16 until BAR_COUNT) tr += lv[i]
                tr /= 16f
                driver.bass = b
                driver.mid = m
                driver.treble = tr

                if (playing) {
                    if (b > slowBass * 1.22f + 0.05f && driver.beat < 0.35f) {
                        driver.beat = 1f
                    }
                    driver.travel = driver.travel + dt * (0.25f + 1.8f * b)
                }
                slowBass += (b - slowBass) * 0.04f
                driver.beat = (driver.beat - dt * 3.2f).coerceAtLeast(0f)
            }
        }
    }
    return driver
}

/** Full-screen reactive background: bass glow, beat flash and floating theme icons. */
@Composable
fun AmbientReactiveLayer(
    style: ThemeStyleSpec,
    driver: AudioDriver,
    modifier: Modifier = Modifier
) {
    val painter = rememberVectorPainter(style.icons.ambient)
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val beat = driver.beat
        val bass = driver.bass
        val mid = driver.mid

        val glowCenter = Offset(w / 2f, h * 0.30f)
        val glowR = w * (0.55f + 0.35f * bass + 0.12f * beat)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    style.accentPrimary.copy(alpha = (0.10f + 0.22f * bass + 0.12f * beat).coerceIn(0f, 0.6f)),
                    Color.Transparent
                ),
                center = glowCenter,
                radius = glowR
            ),
            radius = glowR,
            center = glowCenter
        )

        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    style.accentSecondary.copy(alpha = (0.06f + 0.20f * beat).coerceIn(0f, 0.5f))
                ),
                startY = h * 0.55f,
                endY = h
            )
        )

        val count = 16
        for (i in 0 until count) {
            val speed = 0.035f + (i % 5) * 0.012f
            val p = fract01(i * 0.173f + driver.travel * speed)
            val x = w * fract01(i * 0.6180339f + 0.13f) + sin(p * 12.566f + i) * 18.dp.toPx()
            val y = h * (1.05f - 1.1f * p)
            val sz = (12f + (i % 4) * 6f).dp.toPx() * (1f + 0.5f * beat)
            val a = (sin(p * PI.toFloat()) * (0.16f + 0.30f * mid)).coerceIn(0f, 0.6f)
            val c = if (i % 2 == 0) style.accentPrimary else style.accentSecondary
            translate(left = x - sz / 2f, top = y - sz / 2f) {
                with(painter) {
                    draw(size = Size(sz, sz), alpha = a, colorFilter = ColorFilter.tint(c))
                }
            }
        }
    }
}

/** Tiny 5-bar live spectrum used in the mini player. */
@Composable
fun MiniSpectrum(
    driver: AudioDriver,
    color: Color,
    color2: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val tick = driver.time
        val n = 5
        val gap = 2.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val lvl = driver.levels[(i * 6).coerceAtMost(BAR_COUNT - 1)]
            val bh = size.height * (0.2f + 0.8f * lvl) + tick * 0f
            drawRoundRect(
                color = if (i % 2 == 0) color else color2,
                topLeft = Offset(i * (bw + gap), size.height - bh),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f, bw / 2f)
            )
        }
    }
}
