package com.musicwave.pro.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.RepeatState
import com.musicwave.pro.model.Song
import com.musicwave.pro.model.SortOption
import com.musicwave.pro.viewmodel.MusicViewModel
import kotlin.math.sin

private val BgDark = Color(0xFF0B0C14)
private val CardDark = Color(0xFF17192B)
private val AccentCyan = Color(0xFF00E5FF)
private val AccentPink = Color(0xFFFF2A85)
private val TextPrimary = Color(0xFFF5F7FF)
private val TextSecondary = Color(0xFF9EA4C8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicWaveApp(
    viewModel: MusicViewModel,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onOpenSystemEqualizer: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val allSongs by viewModel.allSongs.collectAsState()
        val currentSong by viewModel.currentSong.collectAsState()
        val isPlaying by viewModel.isPlaying.collectAsState()
        val currentPosition by viewModel.currentPosition.collectAsState()
        val duration by viewModel.duration.collectAsState()
        val shuffleEnabled by viewModel.shuffleEnabled.collectAsState()
        val repeatState by viewModel.repeatState.collectAsState()
        val favorites by viewModel.favorites.collectAsState()
        val playlists by viewModel.playlists.collectAsState()
        val searchQuery by viewModel.searchQuery.collectAsState()
        val sortOption by viewModel.sortOption.collectAsState()
        val playbackSpeed by viewModel.playbackSpeed.collectAsState()
        val bassStrength by viewModel.bassStrength.collectAsState()
        val sleepTimerLeft by viewModel.sleepTimerMinutesLeft.collectAsState()

        var selectedTab by remember { mutableIntStateOf(0) }
        var showFullPlayer by remember { mutableStateOf(false) }
        var showCreatePlaylistDialog by remember { mutableStateOf(false) }
        var songToAddToPlaylist by remember { mutableStateOf<Song?>(null) }
        var activePlaylist by remember { mutableStateOf<Playlist?>(null) }
        var showAudioSettingsSheet by remember { mutableStateOf(false) }

        val filteredSongs = remember(allSongs, searchQuery) {
            if (searchQuery.isBlank()) allSongs
            else allSongs.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.artist.contains(searchQuery, ignoreCase = true) ||
                    it.album.contains(searchQuery, ignoreCase = true)
            }
        }

        Scaffold(
            containerColor = BgDark,
            topBar = {
                TopHeader(
                    searchQuery = searchQuery,
                    onSearchChange = viewModel::updateSearchQuery,
                    sleepTimerLeft = sleepTimerLeft,
                    onOpenSettings = { showAudioSettingsSheet = true },
                    onRefresh = { viewModel.loadSongs() }
                )
            },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (currentSong != null) {
                        MiniPlayerBar(
                            song = currentSong!!,
                            isPlaying = isPlaying,
                            progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f,
                            onTogglePlay = viewModel::togglePlayPause,
                            onNext = viewModel::playNext,
                            onClick = { showFullPlayer = true }
                        )
                    }
                    NavigationBar(
                        containerColor = CardDark,
                        tonalElevation = 8.dp
                    ) {
                        val tabs = listOf(
                            Triple("الأغاني", Icons.Default.LibraryMusic, 0),
                            Triple("قوائم التشغيل", Icons.Default.QueueMusic, 1),
                            Triple("المفضلة", Icons.Default.Favorite, 2),
                            Triple("المجلدات", Icons.Default.Folder, 3)
                        )
                        tabs.forEach { (title, icon, index) ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = {
                                    selectedTab = index
                                    activePlaylist = null
                                },
                                icon = { Icon(icon, contentDescription = title) },
                                label = { Text(title, fontWeight = FontWeight.SemiBold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AccentCyan,
                                    selectedTextColor = AccentCyan,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary,
                                    indicatorColor = AccentCyan.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!hasPermission) {
                    PermissionPromptCard(onRequestPermission = onRequestPermission)
                } else {
                    when (selectedTab) {
                        0 -> AllSongsTab(
                            songs = filteredSongs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            favorites = favorites,
                            sortOption = sortOption,
                            onSortChange = viewModel::updateSortOption,
                            onSongClick = { song -> viewModel.playSongFromQueue(song, filteredSongs) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onAddToPlaylist = { songToAddToPlaylist = it },
                            onShuffleAll = {
                                if (filteredSongs.isNotEmpty()) {
                                    viewModel.playSongFromQueue(filteredSongs.random(), filteredSongs.shuffled())
                                }
                            }
                        )

                        1 -> PlaylistsTab(
                            playlists = playlists,
                            allSongs = allSongs,
                            activePlaylist = activePlaylist,
                            currentSong = currentSong,
                            favorites = favorites,
                            onSelectPlaylist = { activePlaylist = it },
                            onBackToPlaylists = { activePlaylist = null },
                            onCreateNew = { showCreatePlaylistDialog = true },
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onRemoveSongFromPlaylist = { plId, sId ->
                                viewModel.removeSongFromPlaylist(plId, sId)
                                activePlaylist = viewModel.playlists.value.find { it.id == plId }
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) }
                        )

                        2 -> FavoritesTab(
                            allSongs = allSongs,
                            favorites = favorites,
                            currentSong = currentSong,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onAddToPlaylist = { songToAddToPlaylist = it }
                        )

                        3 -> FoldersTab(
                            allSongs = allSongs,
                            currentSong = currentSong,
                            favorites = favorites,
                            onPlaySong = { song, queue -> viewModel.playSongFromQueue(song, queue) },
                            onToggleFavorite = { viewModel.toggleFavorite(it.id) },
                            onAddToPlaylist = { songToAddToPlaylist = it }
                        )
                    }
                }
            }
        }

        // Full Now Playing Screen Overlay
        AnimatedVisibility(
            visible = showFullPlayer && currentSong != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            currentSong?.let { song ->
                NowPlayingFullScreen(
                    song = song,
                    isPlaying = isPlaying,
                    currentPosition = currentPosition,
                    duration = duration,
                    shuffleEnabled = shuffleEnabled,
                    repeatState = repeatState,
                    isFavorite = favorites.contains(song.id),
                    playbackSpeed = playbackSpeed,
                    onClose = { showFullPlayer = false },
                    onTogglePlay = viewModel::togglePlayPause,
                    onNext = viewModel::playNext,
                    onPrevious = viewModel::playPrevious,
                    onSeek = viewModel::seekTo,
                    onToggleShuffle = viewModel::toggleShuffle,
                    onCycleRepeat = viewModel::cycleRepeatMode,
                    onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                    onAddToPlaylist = { songToAddToPlaylist = song },
                    onOpenAudioSettings = { showAudioSettingsSheet = true }
                )
            }
        }

        // Create Playlist Dialog
        if (showCreatePlaylistDialog) {
            var newName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showCreatePlaylistDialog = false },
                containerColor = CardDark,
                titleContentColor = TextPrimary,
                textContentColor = TextPrimary,
                title = { Text("إنشاء قائمة تشغيل جديدة", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("اسم القائمة (مثال: مهرجانات ٢٠٢٦)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCyan,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                viewModel.createPlaylist(newName)
                                showCreatePlaylistDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgDark)
                    ) {
                        Text("حفظ", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreatePlaylistDialog = false }) {
                        Text("إلغاء", color = TextSecondary)
                    }
                }
            )
        }

        // Add Song to Playlist Dialog
        songToAddToPlaylist?.let { targetSong ->
            AlertDialog(
                onDismissRequest = { songToAddToPlaylist = null },
                containerColor = CardDark,
                titleContentColor = TextPrimary,
                title = { Text("إضافة "${targetSong.title}" إلى قائمة", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (playlists.isEmpty()) {
                            Text("لا توجد قوائم تشغيل حالياً. أنشئ قائمة جديدة أولاً.", color = TextSecondary)
                        } else {
                            playlists.forEach { pl ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            viewModel.addSongToPlaylist(pl.id, targetSong.id)
                                            songToAddToPlaylist = null
                                        },
                                    color = BgDark
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(pl.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                                        Text("${pl.songIds.size} أغنية", color = AccentCyan, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        songToAddToPlaylist = null
                        showCreatePlaylistDialog = true
                    }) {
                        Text("+ قائمة جديدة", color = AccentCyan, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { songToAddToPlaylist = null }) {
                        Text("إغلاق", color = TextSecondary)
                    }
                }
            )
        }

        // Audio Effects, Speed & Sleep Timer Sheet
        if (showAudioSettingsSheet) {
            AlertDialog(
                onDismissRequest = { showAudioSettingsSheet = false },
                containerColor = CardDark,
                titleContentColor = TextPrimary,
                title = { Text("المؤثرات الصوتية ومؤقت النوم", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("تعزيز البيز (Bass Boost): ${(bassStrength / 10)}%", color = AccentCyan, fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = bassStrength.toFloat(),
                            onValueChange = { viewModel.setBassBoostStrength(it.toInt()) },
                            valueRange = 0f..1000f,
                            colors = SliderDefaults.colors(thumbColor = AccentCyan, activeTrackColor = AccentCyan)
                        )

                        Text("سرعة التشغيل: ${playbackSpeed}x", color = AccentPink, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { spd ->
                                FilterChip(
                                    selected = playbackSpeed == spd,
                                    onClick = { viewModel.setPlaybackSpeed(spd) },
                                    label = { Text("${spd}x") }
                                )
                            }
                        }

                        Text("مؤقت الإيقاف التلقائي (Sleep Timer)", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(null to "إيقاف", 15 to "15 د", 30 to "30 د", 60 to "60 د").forEach { (mins, label) ->
                                FilterChip(
                                    selected = sleepTimerLeft == mins,
                                    onClick = { viewModel.startSleepTimer(mins) },
                                    label = { Text(label) }
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onOpenSystemEqualizer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Equalizer, contentDescription = null, tint = AccentCyan)
                            Spacer(Modifier.width(8.dp))
                            Text("فتح معادل الصوت المتقدم (Equalizer)", color = AccentCyan)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showAudioSettingsSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgDark)
                    ) {
                        Text("تم", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}

@Composable
private fun TopHeader(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    sleepTimerLeft: Int?,
    onOpenSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF191B34), BgDark)
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(AccentCyan, AccentPink))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = BgDark)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MusicWave Pro",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = if (sleepTimerLeft != null) "مؤقت النوم: متبقي $sleepTimerLeft دقيقة" else "مشغل موسيقى احترافي متكامل",
                        color = if (sleepTimerLeft != null) AccentCyan else TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
            Row {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "تحديث المكتبة", tint = TextPrimary)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Tune, contentDescription = "إعدادات الصوت", tint = AccentCyan)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث عن أغنية، فنان، أو ألبوم...", color = TextSecondary) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "مسح", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark,
                focusedBorderColor = AccentCyan,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )
    }
}

@Composable
private fun PermissionPromptCard(onRequestPermission: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.LibraryMusic,
                    contentDescription = null,
                    tint = AccentCyan,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "السماح بالوصول إلى ملفات الصوت",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "يحتاج تطبيق MusicWave Pro إلى إذن قراءة الملفات الصوتية لعرض وتشغيل جميع الأغاني والمهرجانات المحفوظة على هاتفك.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("منح الإذن واستعراض الأغاني", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun AllSongsTab(
    songs: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    sortOption: SortOption,
    onSortChange: (SortOption) -> Unit,
    onSongClick: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onShuffleAll: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = onShuffleAll,
                colors = ButtonDefaults.buttonColors(containerColor = AccentPink, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("تشغيل عشوائي (${songs.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(SortOption.values()) { option ->
                    FilterChip(
                        selected = sortOption == option,
                        onClick = { onSortChange(option) },
                        label = { Text(option.labelAr, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentCyan.copy(alpha = 0.2f),
                            selectedLabelColor = AccentCyan,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        if (songs.isEmpty()) {
            EmptyStateBox("لم يتم العثور على مقاطع صوتية على الجهاز")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    SongRowItem(
                        song = song,
                        isSelected = currentSong?.id == song.id,
                        isPlaying = isPlaying && currentSong?.id == song.id,
                        isFavorite = favorites.contains(song.id),
                        onClick = { onSongClick(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(
    playlists: List<Playlist>,
    allSongs: List<Song>,
    activePlaylist: Playlist?,
    currentSong: Song?,
    favorites: Set<Long>,
    onSelectPlaylist: (Playlist) -> Unit,
    onBackToPlaylists: () -> Unit,
    onCreateNew: () -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlaySong: (Song, List<Song>) -> Unit,
    onRemoveSongFromPlaylist: (String, Long) -> Unit,
    onToggleFavorite: (Song) -> Unit
) {
    if (activePlaylist != null) {
        val playlistSongs = remember(activePlaylist, allSongs) {
            allSongs.filter { activePlaylist.songIds.contains(it.id) }
        }
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBackToPlaylists) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = AccentCyan)
                    }
                    Column {
                        Text(activePlaylist.name, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${playlistSongs.size} أغنية", color = TextSecondary, fontSize = 12.sp)
                    }
                }
                if (playlistSongs.isNotEmpty()) {
                    Button(
                        onClick = { onPlaySong(playlistSongs.first(), playlistSongs) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgDark)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("تشغيل القائمة", fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (playlistSongs.isEmpty()) {
                EmptyStateBox("هذه القائمة فارغة. أضف أغاني من تبويب الأغاني باستخدام زر (+)")
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(playlistSongs, key = { it.id }) { song ->
                        SongRowItem(
                            song = song,
                            isSelected = currentSong?.id == song.id,
                            isPlaying = false,
                            isFavorite = favorites.contains(song.id),
                            onClick = { onPlaySong(song, playlistSongs) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onAddToPlaylist = { onRemoveSongFromPlaylist(activePlaylist.id, song.id) },
                            customActionIcon = Icons.Default.RemoveCircleOutline
                        )
                    }
                }
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("قوائم التشغيل الخاصة بك", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = onCreateNew,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = BgDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("قائمة جديدة", fontWeight = FontWeight.Bold)
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(playlists, key = { it.id }) { pl ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectPlaylist(pl) },
                        colors = CardDefaults.cardColors(containerColor = CardDark),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Brush.linearGradient(listOf(AccentPink, AccentCyan))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.QueueMusic, contentDescription = null, tint = BgDark)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(pl.name, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("${pl.songIds.size} مقطع صوتي", color = TextSecondary, fontSize = 13.sp)
                                }
                            }
                            IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoritesTab(
    allSongs: List<Song>,
    favorites: Set<Long>,
    currentSong: Song?,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit
) {
    val favSongs = remember(allSongs, favorites) {
        allSongs.filter { favorites.contains(it.id) }
    }
    if (favSongs.isEmpty()) {
        EmptyStateBox("لم تقم بإضافة أغاني إلى المفضلة بعد")
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(favSongs, key = { it.id }) { song ->
                SongRowItem(
                    song = song,
                    isSelected = currentSong?.id == song.id,
                    isPlaying = false,
                    isFavorite = true,
                    onClick = { onPlaySong(song, favSongs) },
                    onToggleFavorite = { onToggleFavorite(song) },
                    onAddToPlaylist = { onAddToPlaylist(song) }
                )
            }
        }
    }
}

@Composable
private fun FoldersTab(
    allSongs: List<Song>,
    currentSong: Song?,
    favorites: Set<Long>,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit
) {
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    val grouped = remember(allSongs) { allSongs.groupBy { it.folderName } }

    if (selectedFolder != null) {
        val folderSongs = grouped[selectedFolder].orEmpty()
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selectedFolder = null }) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = AccentCyan)
                }
                Text(
                    text = "مجلد: $selectedFolder (${folderSongs.size})",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(folderSongs, key = { it.id }) { song ->
                    SongRowItem(
                        song = song,
                        isSelected = currentSong?.id == song.id,
                        isPlaying = false,
                        isFavorite = favorites.contains(song.id),
                        onClick = { onPlaySong(song, folderSongs) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) }
                    )
                }
            }
        }
    } else {
        if (grouped.isEmpty()) {
            EmptyStateBox("لا توجد مجلدات موسيقية")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(grouped.entries.toList(), key = { it.key }) { (folderName, list) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedFolder = folderName },
                        colors = CardDefaults.cardColors(containerColor = CardDark),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(folderName, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("${list.size} أغنية", color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SongRowItem(
    song: Song,
    isSelected: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    customActionIcon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.PlaylistAdd
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) CardDark.copy(alpha = 0.95f) else Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardDark),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = song.albumArtUri,
                    contentDescription = song.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Equalizer else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = AccentCyan
                        )
                    }
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = if (isSelected) AccentCyan else TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${song.artist} • ${formatDuration(song.duration)}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "مفضلة",
                    tint = if (isFavorite) AccentPink else TextSecondary
                )
            }

            IconButton(onClick = onAddToPlaylist) {
                Icon(
                    imageVector = customActionIcon,
                    contentDescription = "إضافة لقائمة",
                    tint = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(
    song: Song,
    isPlaying: Boolean,
    progress: Float,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        color = Color(0xFF20233A),
        tonalElevation = 10.dp
    ) {
        Column {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = AccentCyan,
                trackColor = Color.Transparent
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(AccentCyan, AccentPink))),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = song.albumArtUri,
                        contentDescription = song.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        song.artist,
                        color = AccentCyan,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onTogglePlay) {
                    Icon(
                        if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                        contentDescription = "تشغيل/إيقاف",
                        tint = AccentCyan,
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "التالي", tint = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun NowPlayingFullScreen(
    song: Song,
    isPlaying: Boolean,
    currentPosition: Long,
    duration: Long,
    shuffleEnabled: Boolean,
    repeatState: RepeatState,
    isFavorite: Boolean,
    playbackSpeed: Float,
    onClose: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onOpenAudioSettings: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = BgDark
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1F1638), BgDark, Color(0xFF090A10))
                    )
                )
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "إغلاق", tint = TextPrimary, modifier = Modifier.size(32.dp))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("يعمل الآن", color = AccentCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(song.folderName, color = TextSecondary, fontSize = 11.sp)
                }
                IconButton(onClick = onOpenAudioSettings) {
                    Icon(Icons.Default.Equalizer, contentDescription = "المؤثرات", tint = AccentCyan)
                }
            }

            // Artwork Card + Animated Waveform
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(260.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(Brush.linearGradient(listOf(CardDark, Color(0xFF2B194D)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = AccentCyan.copy(alpha = 0.4f),
                        modifier = Modifier.size(96.dp)
                    )
                    AsyncImage(
                        model = song.albumArtUri,
                        contentDescription = song.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(Modifier.height(20.dp))

                AnimatedVisualizerWave(isPlaying = isPlaying)
            }

            // Song Info + Favorite/Playlist actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        color = TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${song.artist} • ${song.album}",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row {
                    IconButton(onClick = onAddToPlaylist) {
                        Icon(Icons.Default.PlaylistAdd, contentDescription = "إضافة لقائمة", tint = TextPrimary)
                    }
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "مفضلة",
                            tint = if (isFavorite) AccentPink else TextPrimary
                        )
                    }
                }
            }

            // SeekBar & Controls
            Column(modifier = Modifier.fillMaxWidth()) {
                val safeDuration = duration.coerceAtLeast(1L)
                Slider(
                    value = currentPosition.coerceIn(0L, safeDuration).toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..safeDuration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = AccentCyan,
                        activeTrackColor = AccentCyan,
                        inactiveTrackColor = CardDark
                    )
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatDuration(currentPosition), color = TextSecondary, fontSize = 12.sp)
                    Text("${playbackSpeed}x", color = AccentPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(formatDuration(duration), color = TextSecondary, fontSize = 12.sp)
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onToggleShuffle) {
                        Icon(
                            Icons.Default.Shuffle,
                            contentDescription = "عشوائي",
                            tint = if (shuffleEnabled) AccentCyan else TextSecondary
                        )
                    }

                    IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.SkipNext, contentDescription = "السابق", tint = TextPrimary, modifier = Modifier.size(36.dp))
                    }

                    FloatingActionButton(
                        onClick = onTogglePlay,
                        containerColor = AccentCyan,
                        contentColor = BgDark,
                        shape = CircleShape,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "تشغيل",
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "التالي", tint = TextPrimary, modifier = Modifier.size(36.dp))
                    }

                    IconButton(onClick = onCycleRepeat) {
                        val icon = when (repeatState) {
                            RepeatState.ONE -> Icons.Default.RepeatOne
                            else -> Icons.Default.Repeat
                        }
                        val tint = if (repeatState == RepeatState.OFF) TextSecondary else AccentCyan
                        Icon(icon, contentDescription = "تكرار", tint = tint)
                    }
                }
            }
        }
    }
}

@Composable
private fun AnimatedVisualizerWave(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(38.dp)
    ) {
        val barCount = 28
        val space = 6.dp.toPx()
        val barWidth = (size.width - (barCount - 1) * space) / barCount
        for (i in 0 until barCount) {
            val factor = if (isPlaying) {
                (0.25f + 0.75f * kotlin.math.abs(sin(phase + i * 0.45f)))
            } else {
                0.2f
            }
            val barHeight = size.height * factor
            val x = i * (barWidth + space)
            val y = (size.height - barHeight) / 2f
            drawRoundRect(
                color = if (i % 2 == 0) AccentCyan else AccentPink,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}

@Composable
private fun EmptyStateBox(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.MusicOff, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(12.dp))
            Text(message, color = TextSecondary, fontSize = 15.sp)
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
