package com.musicwave.pro.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.musicwave.pro.model.AppThemeType
import com.musicwave.pro.model.PersistedSettings
import com.musicwave.pro.model.Playlist
import com.musicwave.pro.model.RepeatState
import com.musicwave.pro.model.SortOption
import com.musicwave.pro.model.VisualizerMode

class MusicDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "musicwave_pro.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS favorites (
                song_id INTEGER PRIMARY KEY
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS playlists (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS playlist_songs (
                playlist_id TEXT NOT NULL,
                song_id INTEGER NOT NULL,
                position INTEGER NOT NULL,
                PRIMARY KEY (playlist_id, song_id)
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS song_lyrics (
                song_id INTEGER PRIMARY KEY,
                lyrics_text TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS app_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            )
            """.trimIndent()
        )

        val defaults = listOf(
            "pl_shaabi" to "مهرجانات وشعبي",
            "pl_chill" to "روقان وموال",
            "pl_workout" to "حماس وجيم"
        )
        val now = System.currentTimeMillis()
        defaults.forEach { (id, name) ->
            val cv = ContentValues().apply {
                put("id", id)
                put("name", name)
                put("created_at", now)
            }
            db.insertWithOnConflict("playlists", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }

    fun getFavoriteIds(): Set<Long> {
        val result = mutableSetOf<Long>()
        readableDatabase.rawQuery("SELECT song_id FROM favorites", null).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(cursor.getLong(0))
            }
        }
        return result
    }

    fun setFavorite(songId: Long, isFav: Boolean) {
        val db = writableDatabase
        if (isFav) {
            val cv = ContentValues().apply { put("song_id", songId) }
            db.insertWithOnConflict("favorites", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            db.delete("favorites", "song_id = ?", arrayOf(songId.toString()))
        }
    }

    fun getPlaylists(): List<Playlist> {
        val playlists = mutableListOf<Playlist>()
        val db = readableDatabase
        db.rawQuery("SELECT id, name, created_at FROM playlists ORDER BY created_at ASC", null).use { cursor ->
            while (cursor.moveToNext()) {
                val plId = cursor.getString(0)
                val name = cursor.getString(1)
                val createdAt = cursor.getLong(2)
                val songIds = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT song_id FROM playlist_songs WHERE playlist_id = ? ORDER BY position ASC",
                    arrayOf(plId)
                ).use { sCursor ->
                    while (sCursor.moveToNext()) {
                        songIds.add(sCursor.getLong(0))
                    }
                }
                playlists.add(Playlist(id = plId, name = name, songIds = songIds, createdAt = createdAt))
            }
        }
        return playlists
    }

    fun createPlaylist(playlist: Playlist) {
        val cv = ContentValues().apply {
            put("id", playlist.id)
            put("name", playlist.name)
            put("created_at", playlist.createdAt)
        }
        writableDatabase.insertWithOnConflict("playlists", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deletePlaylist(playlistId: String) {
        val db = writableDatabase
        db.delete("playlist_songs", "playlist_id = ?", arrayOf(playlistId))
        db.delete("playlists", "id = ?", arrayOf(playlistId))
    }

    fun addSongToPlaylist(playlistId: String, songId: Long) {
        val db = writableDatabase
        var nextPos = 0L
        db.rawQuery(
            "SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlist_id = ?",
            arrayOf(playlistId)
        ).use { c ->
            if (c.moveToFirst()) nextPos = c.getLong(0)
        }
        val cv = ContentValues().apply {
            put("playlist_id", playlistId)
            put("song_id", songId)
            put("position", nextPos)
        }
        db.insertWithOnConflict("playlist_songs", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun removeSongFromPlaylist(playlistId: String, songId: Long) {
        writableDatabase.delete(
            "playlist_songs",
            "playlist_id = ? AND song_id = ?",
            arrayOf(playlistId, songId.toString())
        )
    }

    fun updatePlaylistSongOrder(playlistId: String, orderedSongIds: List<Long>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("playlist_songs", "playlist_id = ?", arrayOf(playlistId))
            orderedSongIds.forEachIndexed { index, songId ->
                val cv = ContentValues().apply {
                    put("playlist_id", playlistId)
                    put("song_id", songId)
                    put("position", index.toLong())
                }
                db.insertWithOnConflict("playlist_songs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun getCustomLyrics(songId: Long): String? {
        readableDatabase.rawQuery(
            "SELECT lyrics_text FROM song_lyrics WHERE song_id = ?",
            arrayOf(songId.toString())
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(0)
            }
        }
        return null
    }

    fun saveCustomLyrics(songId: Long, lyrics: String) {
        val cv = ContentValues().apply {
            put("song_id", songId)
            put("lyrics_text", lyrics)
        }
        writableDatabase.insertWithOnConflict("song_lyrics", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun saveSetting(key: String, value: String) {
        val cv = ContentValues().apply {
            put("setting_key", key)
            put("setting_value", value)
        }
        writableDatabase.insertWithOnConflict("app_settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getAllSettingsMap(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        readableDatabase.rawQuery("SELECT setting_key, setting_value FROM app_settings", null).use { c ->
            while (c.moveToNext()) {
                map[c.getString(0)] = c.getString(1)
            }
        }
        return map
    }

    fun loadPersistedSettings(): PersistedSettings {
        val m = getAllSettingsMap()
        val bandsStr = m["eq_bands"] ?: "0,0,0,0,0"
        val parsedBands = bandsStr.split(",").mapNotNull { it.toIntOrNull() }
        val eqBands = if (parsedBands.size == 5) parsedBands else listOf(0, 0, 0, 0, 0)

        return PersistedSettings(
            themeId = m["theme_id"] ?: AppThemeType.NEON_CYBER.id,
            visualizerId = m["visualizer_id"] ?: VisualizerMode.SPECTRUM_PEAKS.id,
            sortOptionName = m["sort_option"] ?: SortOption.DATE_ADDED.name,
            shuffleEnabled = m["shuffle_enabled"]?.toBooleanStrictOrNull() ?: false,
            repeatStateName = m["repeat_state"] ?: RepeatState.OFF.name,
            playbackSpeed = m["playback_speed"]?.toFloatOrNull()?.coerceIn(0.5f, 2.0f) ?: 1.0f,
            bassStrength = m["bass_strength"]?.toIntOrNull()?.coerceIn(0, 1000) ?: 0,
            activePresetId = m["active_preset_id"] ?: "flat",
            eqBands = eqBands,
            lastSongId = m["last_song_id"]?.toLongOrNull() ?: -1L,
            lastPositionMs = m["last_position_ms"]?.toLongOrNull() ?: 0L,
            ambientFxEnabled = m["ambient_fx"]?.toBooleanStrictOrNull() ?: true
        )
    }
}
