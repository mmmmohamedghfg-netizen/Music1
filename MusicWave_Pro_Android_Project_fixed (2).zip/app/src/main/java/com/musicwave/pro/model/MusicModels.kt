package com.musicwave.pro.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val contentUri: Uri,
    val albumArtUri: Uri?,
    val folderName: String,
    val filePath: String,
    val dateAdded: Long
)

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>,
    val createdAt: Long = System.currentTimeMillis()
)

enum class SortOption(val labelAr: String) {
    TITLE("الاسم"),
    ARTIST("الفنان"),
    DURATION("المدة"),
    DATE_ADDED("الأحدث")
}

enum class RepeatState {
    OFF, ALL, ONE
}

data class EqPreset(
    val id: String,
    val nameAr: String,
    val bandGainsMb: List<Int> // 5 bands in millibels (-1500 to +1500)
)

enum class AppThemeType(
    val id: String,
    val titleAr: String,
    val subtitleAr: String
) {
    NEON_CYBER("neon_cyber", "نيون سايبر (Neon Cyber)", "إضاءة نيون سماوي وفوشيا بحواف انسيابية وأيقونات الموجات"),
    LA_CASA_RED("la_casa_red", "البروفيسور (La Casa Red)", "أحمر قرمزي وأسود تكتيكي بحواف حادة وأيقونات المسرح القتالي"),
    ROYAL_GOLD("royal_gold", "الملكي الذهبي (Royal Gold)", "ذهبي فاخر مع خلفية مخملية داكنة وإطارات ملكية وأيقونات النجوم"),
    SHAABI_FESTIVAL("shaabi_festival", "مهرجانات شعبي (Street Festival)", "برتقالي ناري وبنفسجي ليزر مع بطاقات بارزة وأيقونات السماعات الضخمة"),
    RETRO_VINYL("retro_vinyl", "اسطوانة كلاسيك (Retro Vinyl)", "كهرماني دافئ وطابع كاسيت واسطوانات كلاسيكية دائرية"),
    EMERALD_GLASS("emerald_glass", "زمردي زجاجي (Emerald Glass)", "أخضر زمردي مضيء مع بطاقات زجاجية ناعمة وأيقونات الاستوديو"),
    OCEAN_DEEP("ocean_deep", "محيط عميق (Deep Ocean)", "أزرق بحري وفيروزي مع أمواج وأيقونات البحر تطفو مع الإيقاع"),
    SUNSET_BLAZE("sunset_blaze", "غروب ملتهب (Sunset Blaze)", "برتقالي وذهبي دافئ مثل الغروب مع شموس وأيقونات الطبيعة"),
    SAKURA_PINK("sakura_pink", "ساكورا وردي (Sakura Bloom)", "وردي ناعم وبنفسجي مع زهور متطايرة وحواف مستديرة"),
    GALAXY_VIOLET("galaxy_violet", "مجرة بنفسجية (Galaxy)", "بنفسجي كوني وأزرق مع نجوم ووميض فضائي"),
    MATRIX_HACKER("matrix_hacker", "ماتريكس (Matrix Hacker)", "أخضر نيون على أسود بطابع الأكواد والشيفرة"),
    ICE_FROST("ice_frost", "جليد متجمد (Ice Frost)", "أزرق جليدي بارد مع ندف ثلج وبلورات متلألئة")
}

enum class VisualizerMode(
    val id: String,
    val titleAr: String
) {
    SPECTRUM_PEAKS("spectrum_peaks", "أعمدة الطيف بقمم متساقطة (Pro Spectrum)"),
    CIRCULAR_HALO("circular_halo", "نبض الهالة الدائري 360° (Radial Bass Halo)"),
    DUAL_WAVE("dual_wave", "موجات الأوسيلوسكوب المزدوجة (Neon Ribbon Waves)"),
    BEAT_PARTICLES("beat_particles", "انفجار الجزيئات والنجوم (Beat Particles)"),
    VINYL_DECK("vinyl_deck", "الاسطوانة الدوارة التفاعلية (Live Vinyl Deck)"),
    LED_MATRIX("led_matrix", "مصفوفة الإيكولايزر المضيئة (LED Matrix & Mirror)"),
    AURORA_WAVES("aurora_waves", "الشفق القطبي المتموج (Aurora Waves)"),
    STARFIELD_WARP("starfield_warp", "عبور النجوم بسرعة الضوء (Starfield Warp)"),
    FIRE_EQ("fire_eq", "إيكولايزر اللهب (Fire Equalizer)"),
    LIQUID_BLOB("liquid_blob", "الكتلة السائلة النابضة (Liquid Blob)"),
    LASER_GRID("laser_grid", "شبكة الليزر والسينث ويف (Laser Synthwave)"),
    RIPPLE_RINGS("ripple_rings", "حلقات الموجات الصادمة (Shockwave Ripples)"),
    MIRROR_SPECTRUM("mirror_spectrum", "الطيف المتماثل المنعكس (Mirror Spectrum)"),
    DNA_HELIX("dna_helix", "الحلزون الصوتي (Audio Helix)")
}

data class PersistedSettings(
    val themeId: String = AppThemeType.NEON_CYBER.id,
    val visualizerId: String = VisualizerMode.SPECTRUM_PEAKS.id,
    val sortOptionName: String = SortOption.DATE_ADDED.name,
    val shuffleEnabled: Boolean = false,
    val repeatStateName: String = RepeatState.OFF.name,
    val playbackSpeed: Float = 1.0f,
    val bassStrength: Int = 0,
    val activePresetId: String = "flat",
    val eqBands: List<Int> = listOf(0, 0, 0, 0, 0),
    val lastSongId: Long = -1L,
    val lastPositionMs: Long = 0L,
    val ambientFxEnabled: Boolean = true
)

data class LrcLine(
    val timeMs: Long,
    val text: String
)
